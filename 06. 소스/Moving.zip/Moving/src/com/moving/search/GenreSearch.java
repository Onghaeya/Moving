package com.moving.search;

import java.util.ArrayList;

import com.moving.DTO.MovieDTO;
import com.moving.info.MovieInfo;
import com.moving.main.Getters;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 장르 검색 클래스
 * @author 해나
 *
 */
public class GenreSearch extends Getters implements Search {
	
	/**
	 * 장르 검색 메소드
	 */
	public void search() {
		
		boolean loop = true;
		
		while(loop) {
		
			UI.clear();
			UI.title("장르 검색");
			SearchUI.getSubMenu();
			
			for(int i=0; i<Main.genreList.size(); i++) {
				System.out.printf("%2s. %-10s  \t"
												, Main.genreList.get(i).getSeq()
												, Main.genreList.get(i).getGenre());
				if((i + 1) % 3 == 0) {
					System.out.println();
				}
			}
			System.out.println();
			System.out.println();
			System.out.print("검색할 장르 번호를 입력하세요 > ");
			String sel = scan.nextLine();
			
			if(sel.equals("0")) {
				return;
			}
			
			int count = 0;
			ArrayList<String> seqList = new ArrayList<String>();
			System.out.println();
			System.out.println();
			SearchUI.getMovieListHeader();
			
			for(MovieDTO m : Main.movieList) {
				if(m.getGenreSeq().equals(sel)) {
					System.out.printf("%5s\t%-10.8s \t%s\t%-8s\t%-8.5s\t%5s\n"
							, m.getSeq()
							, m.getTitle()
							, getYear(m.getStartDay())
							, getGenre(m.getGenreSeq())
							, getDirector(m.getSeq())
							, getStar(m.getReviewerNum(), m.getTotalScore()));
					
					seqList.add(m.getSeq());
					count++;
				}
			}
			
			if(count > 0) {
				
				System.out.println();
				System.out.print("영화 상세보기(번호입력) : ");
				sel = scan.nextLine();
				
				if(sel.equals("0")) {
					continue;
				}
				
				if(seqList.contains(sel)) {
					MovieInfo.info(sel);
					
				} else {
					System.out.println("정확한 번호를 입력하세요.");
					UI.enterPause();
				}	
				
			} else {
				System.out.println("검색 결과가 없습니다.");
				UI.enterPause();
			}
				
		}
	
	}
	
	
}

package com.moving.search;

import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.plaf.synth.SynthSpinnerUI;

import com.moving.DTO.MovieDTO;
import com.moving.info.MovieInfo;
import com.moving.main.Getters;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 연도별 영화 검색
 * @author 해나
 *
 */
public class YearSearch extends Getters implements Search {

	/**
	 * 연도별 영화를 검색하는 메소드
	 */
	public void search() {
		
		boolean loop = true;
		int startYear = 0;
		int endYear = 0;
		
		while(loop) {
			UI.clear();
			UI.title("연도별 검색");
			SearchUI.getSubMenu();
			
			System.out.println("1. 1980년대\n");
			System.out.println("2. 1990년대\n");
			System.out.println("3. 2000년대\n");
			System.out.println("4. 2010년대\n");
			System.out.println("5. 올해의 영화\n");
			
			System.out.print("번호를 입력하세요 > ");
			String sel = scan.nextLine();
			
			if(sel.equals("0")) {
				return;
			}
			
			if(sel.equals("1")) {
				startYear = 1980;
				endYear = 1990;
			} else if(sel.equals("2")) {
				startYear = 1990;
				endYear = 2000;
			} else if(sel.equals("3")) {
				startYear = 2000;
				endYear = 2010;
			} else if(sel.equals("4")) {
				startYear = 2010;
				endYear = 2020;
			} else if(sel.equals("5")) {
				Calendar c = Calendar.getInstance();
				startYear = c.get(c.YEAR);
				endYear = startYear + 1;					
			}
		
			int count = 0;
			ArrayList<String> seqList = new ArrayList<String>();
			
			SearchUI.getMovieListHeader();
			
			for(int i=0; i<Main.movieList.size(); i++) {
				
				if(getYear(Main.movieList.get(i).getStartDay()) >= startYear 
						&& getYear(Main.movieList.get(i).getStartDay()) < endYear) {
					
					System.out.printf("%5s\t%-10.7s   \t%s\t%-10s \t%8.5s\t%6s\n"
									, Main.movieList.get(i).getSeq()
									, Main.movieList.get(i).getTitle()
									, getYear(Main.movieList.get(i).getStartDay())
									, getGenre(Main.movieList.get(i).getGenreSeq())
									, getDirector(Main.movieList.get(i).getSeq())
									, getStar(Main.movieList.get(i).getReviewerNum(), Main.movieList.get(i).getTotalScore()));
							
					seqList.add(Main.movieList.get(i).getSeq());
					count++;
					
					if((seqList.size()) % 15 == 0) {
						System.out.println("\n다음 목록은 엔터, 영화 상세보기는 영화 번호를 입력하세요.");
						System.out.print("입력 > ");
						sel = scan.nextLine();
						System.out.println();
					
						if(sel.equals("")) {
							continue;
						} else if(sel.equals("0")) {
							return;
						} else {
							break;
						}
					}
					
				}
			}
			
			if(count > 0) {
				
				if(seqList.contains(sel)) {
					MovieInfo.info(sel);
					
				} else {
					System.out.println("정확한 번호를 입력하세요.");
					UI.enterPause();
				}	
				
			} else {
				System.out.println("검색 결과를 찾을 수 없습니다.");
				UI.enterPause();
			}
		}
	
	}
	
		
}	

	


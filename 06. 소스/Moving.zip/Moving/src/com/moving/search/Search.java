package com.moving.search;

/**
 * 검색 관련 클래스에 상속하는 인터페이스
 * @author SIST
 *
 */
public interface Search {
	
	void search();
}

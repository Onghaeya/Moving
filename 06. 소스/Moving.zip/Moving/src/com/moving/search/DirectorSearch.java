package com.moving.search;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.DirectorDTO;
import com.moving.info.DirectorInfo;
import com.moving.main.Getters;
import com.moving.main.Main;
import com.moving.main.UI;


/**
 * 감독 검색
 * @author 해나
 *
 */
public class DirectorSearch extends Getters implements Search {

	/**
	 * 감독 검색 메소드
	 */
	public void search() {
		
		String name = "";
		
		System.out.printf("검색할 감독의 이름을 입력하세요 > ");
		name = scan.nextLine();
		System.out.println();
		System.out.println();
		
		int count = 0;
		
		if(!name.equals("")) {
			
			SearchUI.getDirectorListHeader();
			ArrayList<String> seqList = new ArrayList<String>();
			
			for(DirectorDTO d : Main.directorList) {
				//[영화번호]\t[제목]\t\t[연도]\t[장르]\t[감독]\t\t[별점]
				//출력 예쁘게 수정
				if((d.getName().replace(" ", "")).contains(name.replace(" ", ""))) {
					System.out.printf("%5s\t%-6.5s \t%s\t%s\t\t%.20s\t\n"
													, d.getSeq()
													, d.getName()
													, getAge(d.getBirthday())
													, getCountry(d.getCountrySeq())
													, getMajorWork(d.getSeq(), 0));
			
					seqList.add(d.getSeq());
					count++;
				}	
			}
			
			if(count > 0) {
				System.out.println();
				System.out.print("감독 상세보기(번호입력) > ");
				String sel = scan.nextLine();
				
				if(name.equals("0")) {
					return;
				}
				
				
				if(seqList.contains(sel)) {
					DirectorInfo dInfo = new DirectorInfo();
					dInfo.info(sel);	
					 
				} else {
					System.out.println("정확한 번호를 입력하세요.");
					UI.enterPause();
				}

				
			} else {
				System.out.println("해당 이름을 찾을 수 없습니다.");
				System.out.println();
				UI.enterPause();
				System.out.println();
				System.out.println();
			}
		} else {
			System.out.println("정확한 단어를 입력하세요");
			UI.enterPause();
		}
	}




		
	
}

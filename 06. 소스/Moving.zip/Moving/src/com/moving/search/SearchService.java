package com.moving.search;
import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.*;
import com.moving.admin.book.EditOnscreen;
import com.moving.main.Main;
import com.moving.main.UI;
/**
 * 검색 서비스 관련 클래스
 * @author user
 *
 */
public class SearchService {

	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	
	/**
	 * 검색 첫 메뉴
	 */
	public void searchMenu() {
		
		String sel = "";
		boolean loop = true;
		
		while(loop) {
			
			UI.clear();
	 		UI.title("영화 검색");
			SearchUI.getMenu();
			
			System.out.print("원하시는 검색을 선택해주세요 > ");
			sel = scan.nextLine();
			
			
			if(sel.equals("1")) {
				MovieSearch m = new MovieSearch();
				m.search();
				
			} else if(sel.equals("2")) {
				ArtistSearch a = new ArtistSearch();
				a.search();
		
			} else if(sel.equals("3")) {
				GenreSearch g = new GenreSearch();
				g.search();
			
			} else if(sel.equals("4")) {
				YearSearch y = new YearSearch();
				y.search();
		
			}else if(sel.equals("0")) {
				//상위메뉴로
				loop = false;
			} else {
				SearchUI.inputError();
				UI.enterPause();
			}
		
		}
		
	}
	



	
}



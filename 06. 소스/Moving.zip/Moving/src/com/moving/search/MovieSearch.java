package com.moving.search;
import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.MovieDTO;
import com.moving.admin.book.EditOnscreen;
import com.moving.info.MovieInfo;
import com.moving.main.Getters;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 영화 검색 클래스
 * @author 해나
 *
 */
public class MovieSearch extends Getters implements Search {
		
/**
 * 영화 검색 메소드
 * @param mode 0=영화상세보기 위한 검색/1=리스트만 출력
 */
	public void search() {
		
		boolean loop = true;
		boolean count = true;
		
		while(loop) {
			System.out.printf("\n검색할 영화의 제목을 입력하세요(한글) > ");
			
			String title = scan.nextLine();
		
			System.out.println();
			System.out.println();
	
			if(title.equals("0")) {
				return;
			}
				
			if(!title.equals("")) {
				SearchUI.getMovieListHeader();
				
				for(MovieDTO m : Main.movieList) {
				
					//TODO 출력 예쁘게 수정
					if((m.getTitle().replace(" ", "")).contains(title.replace(" ", ""))) {
					//	System.out.printf("%5s\t%-10.10s     \t%-10s\t%-7s\t%s\t%.2f%%\n"
						System.out.printf("%5s\t%-10.7s   \t%s\t%-10s  \t%-8.7s\t%s\n"
								
														, m.getSeq()
														, m.getTitle()
														, getYear(m.getStartDay())
														, getGenre(m.getGenreSeq())
														, getDirector(m.getSeq())
														, getStar(m.getReviewerNum(), m.getTotalScore()));
						
						EditOnscreen.seqList.add(m.getSeq());				
						count = false;
					}	

				}
				
				if(count) {
					System.out.println("영화를 찾을 수 없습니다.");
					System.out.println();
					UI.enterPause();
					System.out.println();
					System.out.println();
					
				} else {					
					detailSelect(EditOnscreen.seqList);	
					loop = false;
				}
				
			} else {
				SearchUI.inputError();
				UI.enterPause();
			}
		}
		
	}
	
	public void detailSelect(ArrayList<String> seqList) {
		
		boolean loop = true;
		
		while(loop) {
		
			System.out.println();
		
			System.out.print("영화 상세보기(번호입력) : ");	
			String sel = scan.nextLine();
			
			if(seqList.contains(sel)) {
				MovieInfo.info(sel);		
				return;
			} else if(sel.equals("0")){
				loop = false;
			} else {
				System.out.println("정확한 번호를 입력하세요.");		
				UI.enterPause();
			}
		
		}
	}

}

package com.moving.search;

import java.util.Scanner;

import com.moving.main.UI;


/**
 * 검색 UI
 * @author 해나
 *
 */
public class SearchUI {
	
	
	public static void getMenu() {
		System.out.println("1. 제목검색  2. 인물검색  3. 장르검색  4. 개봉연도검색  0. 상위메뉴로");
		UI.line();
	}
	
	public static void getArtistMenu() {
		System.out.println("1. 감독 검색   2. 배우 검색   0. 상위메뉴로");
	}
	
	public static void getSubMenu() {
		System.out.println("0. 상위메뉴로");
		UI.line();
	}
	
	public static void getMovieListHeader() {
		System.out.println("[번호]             [제목]      [연도]       [장르]   [감독]    \t[별점]");
		UI.line();
	
	}
	
	public static void getBookingListHeader() {
		System.out.println("[번호]   [제목]         [장르]         [감독]           [별점]         [예매율]");
		UI.line();
	}
	
	public static void getDirectorListHeader() {
		System.out.println("[번호]\t[이름]   \t[나이]\t[국적]  \t\t[대표작]");
		UI.line();
	}
	
	public static void pause() {
		Scanner scan = new Scanner(System.in);
		System.out.println("[Enter]");
		scan.nextLine();
		
	}
	
	public static void inputError() {
		System.out.println("잘못된 입력입니다. 다시 입력해주세요.");
	}
}

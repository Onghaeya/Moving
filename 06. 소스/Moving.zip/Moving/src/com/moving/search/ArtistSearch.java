package com.moving.search;
import java.util.Scanner;

import com.moving.main.Getters;
import com.moving.main.UI;

/**
 * 영화인 검색
 * @author 해나
 *
 */
public class ArtistSearch extends Getters implements Search {
	
	/**
	 * 영화인 검색 메소드
	 */
	public void search() {	
			
		boolean loop = true;
			
		while(loop) {
			UI.clear();
			UI.title("인물 검색");
			SearchUI.getArtistMenu();
			UI.line();
				//감독검색 배우검색
			//Scanner scan = new Scanner(System.in);
			
			System.out.printf("검색할 항목 > ");
			String sel = scan.nextLine();
			
			if(sel.equals("1")) {
				DirectorSearch directorSearch = new DirectorSearch();
				directorSearch.search();
			} else if(sel.equals("2")) {
				ActorSearch actorSearch = new ActorSearch();
				actorSearch.search();
			} else if(sel.equals("0")){
				loop = false;
			} else {
				SearchUI.inputError();
				UI.enterPause();
			}
				
		}
	}
}

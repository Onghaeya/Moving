package com.moving.search;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.ActorDTO;
import com.moving.info.ActorInfo;
import com.moving.main.Getters;
import com.moving.main.Main;
import com.moving.main.UI;


/**
 * 배우 검색
 * @author 해나
 *
 */
public class ActorSearch extends Getters implements Search {

	/**
	 * 배우 검색 메소드
	 */
	public void search() {
		
		String name = "";
		
		System.out.printf("검색할 배우의 이름을 입력하세요 > ");
		name = scan.nextLine();
		
		int count = 0;
		

		if(!name.equals("")) {
			
			SearchUI.getDirectorListHeader();
			ArrayList<String> seqList = new ArrayList<String>();
			
			System.out.println();
			for(ActorDTO a: Main.actorList) {
				
				//출력 예쁘게 수정
				if((a.getName().replace(" ", "")).contains(name.replace(" ", ""))) {
					System.out.printf("%5s\t%-6.5s \t%s\t%s\t\t%s\t\n"
					//System.out.printf("%4s\t%-7s\t%s\t%s\t%-7s\t\n"
													, a.getSeq()
													, a.getName()
													, getAge(a.getBirth())
													, getCountry(a.getCountrySeq())
													, getMajorWork(a.getSeq(), 1));
			
					seqList.add(a.getSeq());
					count++;
				}	
			}
			
			if(count > 0) {
				System.out.println();
				System.out.print("배우 상세보기(번호입력) : ");
				String sel = scan.nextLine();
				
				if(name.equals("0")) {
					return;
				}
				
				
				if(seqList.contains(sel)) {
					ActorInfo aInfo = new ActorInfo();
					 aInfo.info(sel);
				} else {
					System.out.println("정확한 번호를 입력하세요.");
					UI.enterPause();
				}

				
			} else {
				System.out.println("해당 이름을 찾을 수 없습니다.");
				System.out.println();
				UI.enterPause();
				System.out.println();
				System.out.println();
			}
		} else {
			System.out.println("정확한 단어를 입력하세요");
			UI.enterPause();
		}
	}
}

package com.moving.main;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.*;

/**
 * 무빙 프로그램을 수행하면서 필요한 모든 DTO 컬렉션화
 * @author 박
 *
 */
public class Main {
	
	private static Scanner scan;
	public static String login; //비회원 -1  관리자 0  회원 1
	public static String memberSeq;
	
	public static ArrayList<ActorDTO> actorList;
	public static ArrayList<ActorFilmoDTO> actorFilmoList;
	public static ArrayList<AwardDTO> awardList;
	public static ArrayList<AwardRecordDTO> awardRecordList;
	public static ArrayList<CompanyDTO> companyList;
	public static ArrayList<CountryDTO> countryList;
	public static ArrayList<DirectorDTO> directorList;
	public static ArrayList<DirectorFilmoDTO> directorFilmoList;
	public static ArrayList<GenreDTO> genreList;
	public static ArrayList<GradeDTO> gradeList;
	public static ArrayList<KeywordDTO> keywordList;
	public static ArrayList<LocalDTO> localList;
	public static ArrayList<MemberDTO> memberList;
	public static ArrayList<MovieDTO> movieList;
	public static ArrayList<MovieKeyDTO> movieKeyList;
	public static ArrayList<OnscreenDTO> onscreenList;
	public static ArrayList<PriceDTO> priceList;
	public static ArrayList<PrizeTypeDTO> prizeTypeList;
	public static ArrayList<RoleDTO> roleList;
	public static ArrayList<TicketDTO> ticketList;
	public static ArrayList<TimeDTO> timeList;
	public static ArrayList<WishlistDTO> wishlistList;
	
	static {
		scan = new Scanner(System.in);
		login = "-1";
		memberSeq = "0";
		
		actorList = new ArrayList<ActorDTO>();
		actorFilmoList = new ArrayList<ActorFilmoDTO>();
		awardList = new ArrayList<AwardDTO>();
		awardRecordList = new ArrayList<AwardRecordDTO>();
		companyList = new ArrayList<CompanyDTO>();
		countryList = new ArrayList<CountryDTO>();
		directorList = new ArrayList<DirectorDTO>();
		directorFilmoList = new ArrayList<DirectorFilmoDTO>();
		genreList = new ArrayList<GenreDTO>();
		gradeList = new ArrayList<GradeDTO>();
		keywordList = new ArrayList<KeywordDTO>();
		localList = new ArrayList<LocalDTO>();
		memberList = new ArrayList<MemberDTO>();
		movieList = new ArrayList<MovieDTO>();
		movieKeyList = new ArrayList<MovieKeyDTO>();
		onscreenList = new ArrayList<OnscreenDTO>();
		priceList = new ArrayList<PriceDTO>();
		prizeTypeList = new ArrayList<PrizeTypeDTO>();
		roleList = new ArrayList<RoleDTO>();
		ticketList = new ArrayList<TicketDTO>();
		timeList = new ArrayList<TimeDTO>();
		wishlistList = new ArrayList<WishlistDTO>();
	}
		
	/**
	 * 프로그램 전체의 main 메소드
	 * @param args
	 */
	public static void main(String[] args) {
		
		FileUtil.load();

		MovingMain.start();
		
		System.out.println("무빙을 이용해주셔서 감사합니다");
		UI.namedPause("종료하시려면 엔터를 눌러주세요");

	}//main
}

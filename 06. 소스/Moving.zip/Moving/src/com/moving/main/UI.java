package com.moving.main;

import java.util.Scanner;

/**
 * 프로그램의 화면 및 기능구현에 공통적으로 필요한 메소드들을 담음
 * @author 박 designed by 해나
 *
 */
public class UI {

	static Scanner scan = new Scanner(System.in);
	private static String input = "";

	/**
	 * 검색어를 요구하여 입력받을 때 사용하는 메소드
	 * @return 입력받은 값을 반환
	 */
	public static String searchPause() {
		System.out.print("검색하실 내용 입력> ");
		input = scan.nextLine();
		return input;
	}//searchPause
	
	
	/**
	 * 수정을 요구하여 입력받을 때 사용하는 메소드
	 * @return 입력받은 값을 반환
	 */
	public static String editPause() {
		System.out.print("수정하실 내용 입력> ");
		input = scan.nextLine();
		return input;
	}//editPause
	
	/**
	 * 프로그램 수행 중 잠시 정지하여 Enter를 입력받을 때 사용하는 메소드
	 */
	public static void enterPause() {
		System.out.printf("[계속하시려면 Enter를 눌러주세요]\n");
		scan.nextLine();
	}//enterPause
	
	/**
	 * 원하는 문자열을 요구하여 입력받을 때 사용하는 메소드
	 * @param name 사용자로부터 입력받기 원하는 것을 받아옴
	 * @return 입력받은 값을 반환
	 */
	public static String namedPause(String name) {
		System.out.printf("%s> ", name);
		input = scan.nextLine();
		return input;
	}//namedPause
	
	/**
	 * 프로그램 수행 중 잠시 정지하여 아무 입력이나 받을 때 사용하는 메소드
	 * @return 입력받은 값을 반환
	 */
	public static String pause() {
		System.out.print("입력> ");
		input = scan.nextLine();
		return input;
	}//pause
	
	/**
	 * 100줄의 공백을 출력하여 화면을 정리하는 메소드
	 */
	public static void clear() {
		for (int i=0;i<100;i++) {
			System.out.println();
		}
	}//clear
	
	/**
	 * --모양의 줄을 하나 출력하는 메소드
	 */
	public static void line() {
		System.out.print("---------------------------------------------------------------------\n");
	}//line
	
	/**
	 * ==모양의 줄을 하나 출력하는 메소드
	 */
	public static void doubleLine() {
		System.out.print("=====================================================================\n");
	}
	
	/**
	 * 제목 템플릿을 출력하는 메소드
	 * @param title 템플릿 사이에 출력할 문자열을 가져옴
	 */
	public static void title(String title) {
		
//		System.out.println("▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼");
//		System.out.println("▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽-▽");
		System.out.print("\n=====================================================================\n");
		System.out.printf("                                     %s                                   \n", title);
		System.out.print("=====================================================================\n");
	
		//System.out.println("ººººººººººººººººººººººººººººººººººººººººººººººººººººººººººººººººººººº");
//		System.out.println("△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△-△△△△△△△△△△△△△△△△");
//		System.out.println("▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲");
	}//title

}//UI
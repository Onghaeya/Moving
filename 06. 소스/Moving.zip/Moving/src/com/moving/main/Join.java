package com.moving.main;

import com.moving.DTO.MemberDTO;
/**
 * 회원 가입 클래스
 * @author 기태 / 박
 *
 */
public class Join {
	
/**
 * 회원가입 혹은 추가를 수행하는 메소드
 * @param mode 1 : 회원 가입모드 0 : 회원추가모드
 */
	public void join(int mode){
		
		MemberDTO addDTO = new MemberDTO();
		
		int seq = 0;
		String id = "", pw = "", name = "", birth = "", mail = "", tel = "";
		boolean loop = true;
		
		UI.clear();
		
		if(mode == 0) {
			UI.title("회원 추가");
		} else {
			UI.title("회원 가입");			
		}
		
		
		seq = Integer.parseInt(Main.memberList.get(Main.memberList.size()-1).getMemberSeq())+1;
		addDTO.setMemberSeq(seq+"");
		
		while (loop) {
			id = UI.namedPause("아이디");
			if(idcheck(id)) {
				addDTO.setId(id);
				loop = false;
			}
		}
		loop = true;
		while (loop) {
			System.out.println();
			pw = UI.namedPause("비밀번호");
			if(pwcheck(pw)) {
				addDTO.setPassword(pw);
				loop = false;
			}
		}
		System.out.println();
		loop = true;
		name = UI.namedPause("이름");
		addDTO.setName(name);
		while (loop) {
			System.out.println("생년월일을 입력해주세요");
			birth = UI.namedPause("ex)19920616");
			if(birthcheck(birth)) {
				birth = birth.substring(0, 4) + "-"  +birth.substring(4, 6) + "-" + birth.substring(6, 8);
				addDTO.setBirthday(birth);
				loop = false;
			}
		}
		loop = true;
		System.out.println();
		mail = UI.namedPause("이메일을 입력해주세요");
		addDTO.setEmail(mail);
		while (loop) {
			System.out.println();
			System.out.println("전화번호를 입력해주세요");
			tel = UI.namedPause("ex)01042954001");
			if(telcheck(tel)) {
				tel = tel.substring(0, 3) + "-" + tel.substring(3, 7) + "-" + tel.substring(7, 11);
				addDTO.setTel(tel);
				loop = false;
			}
		}
		System.out.println();
		Main.memberList.add(addDTO);
		FileUtil.memberSave();
		
		System.out.println("회원가입이 완료되었습니다 :D");
		System.out.println();
		UI.enterPause();
		
	}//join
	

	/**
	 * 회원이 입력한 전화번호를 검증하는 메소드
	 * @param tel 검증할 입력받은 전화번호
	 * @return 검증결과를 반환
	 */
	public boolean telcheck(String tel) {
			
		for(int i=0; i<tel.length();i++){
			char c = tel.charAt(i);
			if(c<'0' || c >'9'){
				System.out.println("숫자만 입력해 주세요.");
				return false;
			}
		}
		return true;
		
	}

		/**
	 * 회원이 입력한 생년월일을 검증하는 메소드 
	 * @param birth 검증할 입력받은 생년월일
	 * @return 검증결과를 반환
	 */
	public boolean birthcheck(String birth) {

		for(int i=0; i<birth.length();i++){
			char c = birth.charAt(i);
			if(c<'0' || c >'9'){
				System.out.println("숫자만 입력해 주세요.");
				return false;
			}
		}
		return true;
		
	}

	/**
	 * 회원이 입력한 비밀번호를 검증하는 메소드
	 * @param pw 검증할 입력받은 비밀번호
	 * @return 검증결과를 반환
	 */
	private boolean pwcheck(String pw) {
		if(pw.length()<4 || pw.length()>12){
			System.out.println("4자 ~ 12자 이내");
			return false;
		}
		return true;
	}

	/**
	 * 회원이 입력한 아이디를 검증하는 메소드
	 * @param id 검증할 입력받은 아이디
	 * @return 검증결과를 반환
	 */
	private boolean idcheck(String id) {
		
		for(MemberDTO m : Main.memberList){
			if(m.getId().equals(id)){
				System.out.println("입력하신 ID는 이미 존재합니다.");
				return false;
			}
			if(id.length()<4 || id.length()>12){
				System.out.println("4자 ~ 12자 이내");
				return false;
				}
				for (int i=0; i<id.length(); i++){
					char c = id.charAt(i);
					if((c < 'A' || c > 'Z') && (c<'a' || c >'z')&& (c<'0' || c >'9') && c != '_'){
						System.out.println("영문자 + 숫자 + _");
						return false;
					}
				}
				if(id.charAt(0)>='0' && id.charAt(0)<='9'){
					System.out.println("숫자 시작 불가능");
					return false;
				}
		}
		return true;
	}
}

package com.moving.main;

import java.util.ArrayList;
import java.util.Random;

import com.moving.admin.book.EditOnscreen;
import com.moving.admin.member.MemberMain;
import com.moving.admin.movie.MovieMain;
import com.moving.booking.BookingService;
import com.moving.info.MemberInfo;
import com.moving.info.MovieInfo;
import com.moving.predict.PredicList;
import com.moving.recommendation.Recommendation;
import com.moving.search.SearchService;

/**
 * 프로그램의 초기 화면
 * @author 박 designed by 해나
 *
 */
class MovingMain {
	
	/**
	 * 프로그램의 초기 화면을 비회원/회원/관리자로 각각 나누어 구현하는 메소드
	 */
	static void start() {
		
		Random rnd = new Random();
		int rndnum = 0;
		ArrayList<String> movies = new ArrayList<String>();
		
		for (int i=0;i<Main.movieList.size();i++) {
			if (Main.movieList.get(i).getState().equals("1")){
				movies.add(Main.movieList.get(i).getSeq());
			}
		}
		
		boolean loop = true;
		String rndSeq = "";
		
		while (loop) {
			if (Main.login.equals("-1")) {
				UI.clear();
				System.out.println("       _  _                              _               ");	     
				System.out.println("     _| || |_                           (_)              ");
				System.out.println("    |_  __  _|   _ __ ___    ___  __   __ _  _ __    __ _ ");
				System.out.println("     _| || |_   | '_ ` _ \\  / _ \\ \\ \\ / /| || '_ \\  / _` |");
				System.out.println("    |_  __  _|  | | | | | || (_) | \\ V / | || | | || (_| |");
				System.out.println("      |_||_|    |_| |_| |_| \\___/   \\_/  |_||_| |_| \\__, |");
				System.out.println("                                                     __/ |");
				System.out.println("                                                    |___/ ");
				
				UI.doubleLine();
				System.out.println("무빙의 모든 기능을 이용하시려면 로그인 해주세요!\n");
				System.out.println("1.영화검색  2.로그인  3.회원가입  0.종료");
				UI.line();
				
				rndnum = rnd.nextInt(movies.size());
				rndSeq = showMovie(rndnum, movies);
				
				loop = mainSelect(rndSeq);
			}
			if (Main.login.equals("1")) {
				UI.clear();
				
				System.out.println("       _  _                              _               ");	     
				System.out.println("     _| || |_                           (_)              ");
				System.out.println("    |_  __  _|   _ __ ___    ___  __   __ _  _ __    __ _ ");
				System.out.println("     _| || |_   | '_ ` _ \\  / _ \\ \\ \\ / /| || '_ \\  / _` |");
				System.out.println("    |_  __  _|  | | | | | || (_) | \\ V / | || | | || (_| |");
				System.out.println("      |_||_|    |_| |_| |_| \\___/   \\_/  |_||_| |_| \\__, |");
				System.out.println("                                                     __/ |");
				System.out.println("                                                    |___/ ");
				System.out.print("\n=====================================================================\n");
				System.out.printf("                                                  "+Main.memberList.get(Integer.parseInt(Main.memberSeq)).getName()+"님 환영합니다"
				+"\n                                                   7.로그아웃  0.종료");//TODO 아스키아트 추가하기
				System.out.print("\n=====================================================================\n");
				System.out.println("1.영화검색 2.추천영화 3.예매 4.나의 정보확인 5.위시리스트 6.흥행예측");
				UI.line();
				
				rndnum = rnd.nextInt(movies.size());
				rndSeq = showMovie(rndnum, movies);
				
				loop = mainSelect(rndSeq);
			}
			if (Main.login.equals("0")) {
				UI.clear();
				
				UI.title("관리자 메뉴");
				System.out.println("1.회원 DB  2.영화/감독/배우 DB  3.상영관 관련 업무 4.관리자 비밀번호 변경 \n0.종료");
				UI.line();
				
				loop = mainSelectAdmin();
			}
		}//while
	}//start
	
	/**
	 * 메인화면에 띄울 현재 상영중인 영화를 선별해서 출력하는 메소드
	 * @param rndnum 받아온 리스트에서 출력할 랜덤으로 만들어진 숫자를 받아옴
	 * @param movies 현재 상영중인 영화만을 모은 ArrayList를 받아옴
	 * @return 랜덤하게 선택된 영화번호를 돌려줌
	 */
	private static String showMovie(int rndnum, ArrayList<String> movies) {
		
		System.out.println("▶ 현재 상영중인 최신 영화 ◀");
		UI.line();
		System.out.println(" << " + Main.movieList.get(Integer.parseInt(movies.get(rndnum))).getTitle() + " >>");
		//UI.line();
		System.out.println();
		System.out.println("* 장르 : "+Main.genreList.get(Integer.parseInt(Main.movieList.get(Integer.parseInt(movies.get(rndnum))).getGenreSeq())).getGenre());
		int score = Main.movieList.get(Integer.parseInt(movies.get(rndnum))).getTotalScore();
		int perScore = Main.movieList.get(Integer.parseInt(movies.get(rndnum))).getReviewerNum();
		String starScore = Getters.getStar(perScore, score);
		
		//System.out.println();
		System.out.println("* 별점  : "+starScore);
		
		//System.out.println();
		System.out.println("* 줄거리");
		String syn = Main.movieList.get(Integer.parseInt(movies.get(rndnum))).getSynopsis();
		System.out.println(" " + Getters.devideLine(syn));
				
		System.out.println("\n"+"[Enter] 이 영화의 상세 정보 보기");
		UI.line();
		
		return Main.movieList.get(Integer.parseInt(movies.get(rndnum))).getSeq();
		
	}//showMovie

	/**
	 * 회원/비회원 상태의 초기 화면에서 있을 분기를 구현하는 메소드
	 * @param rndSeq 초기화면에 출력된 랜덤하게 선택된 영화의 번호
	 * @return 초기화면의 루프 탈출(종료) 여부
	 */
	private static boolean mainSelect(String rndSeq) {
		
		Login in = new Login();
		
		String sel = "";
		try {
			sel = UI.pause();
			
			if (sel.equals("0")) {
				return false;
			} else if (sel.equals("1") && Main.login.equals("-1")) {
				
				SearchService m = new SearchService();
				m.searchMenu();
				
			} else if (sel.equals("1") && Main.login.equals("1")) {

				SearchService m = new SearchService();
				m.searchMenu();
				
			} else if (sel.equals("2") && Main.login.equals("-1")) {
				in.start();
			} else if (sel.equals("2") && Main.login.equals("1")) {
				Recommendation rec = new Recommendation();
				rec.start();
			} else if (sel.equals("3") && Main.login.equals("-1")) {
				Join j = new Join();
				j.join(1);
			} else if (sel.equals("3") && Main.login.equals("1")) {
				
				BookingService b = new BookingService();
				b.bookingMenu();
				
			} else if (sel.equals("4") && Main.login.equals("1")) {
				MemberInfo memberInfo = new MemberInfo();
				memberInfo.info();
			} else if (sel.equals("5") && Main.login.equals("1")) {
				Wishlist w = new Wishlist();
				w.start();
			} else if (sel.equals("6") && Main.login.equals("1")) {
				PredicList p = new PredicList();
				p.predictList();
			} else if (sel.equals("7") && Main.login.equals("1")) {
				System.out.println(Main.memberList.get(Integer.parseInt(Main.memberSeq)).getName()+" 회원님 이용해주셔서 감사합니다");
				Main.login = "-1";
				UI.enterPause();
			} else if (sel.equals("")) {
				MovieInfo.info(rndSeq);
				
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return true;
	}//mainSelect
	
	/**
	 * 관리자 상태의 초기 화면에서 있을 분기를 구현하는 메소드
	 * @return 초기화면의 루프 탈출(종료) 여부
	 */
	private static boolean mainSelectAdmin() {

		MemberMain memberMain = new MemberMain();
		MovieMain movieMain = new MovieMain();
		
		String sel = "";
		try {

			sel = UI.pause();
			
			if (sel.equals("1")) {
				memberMain.start();
			} else if (sel.equals("2")) {
				movieMain.start();
			} else if (sel.equals("3")) {
				EditOnscreen e = new EditOnscreen();
				e.onscreenMenu();
			} else if (sel.equals("4")) {
				
				String pw = "";
				String pwConfirm = "";
				boolean loop2 = true;
				while (loop2) {
					pw = UI.namedPause("변경하실 비밀번호를 입력하세요");
					pwConfirm = UI.namedPause("다시 한번 비밀번호를 입력하세요");
					if (pw.equals(pwConfirm)) {
						Main.memberList.get(0).setPassword(pw);
						FileUtil.memberSave();
						System.out.println("비밀번호가 성공적으로 변경되었습니다");
						UI.enterPause();
						loop2 = false;
					} else {
						System.out.println("입력하신 비밀번호가 같지 않습니다");
					}
				}
				
			} else if (sel.equals("5")) {
				
			} else if (sel.equals("0")) {
				return false;
			} else {}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return true;
	}//mainSelectAdmin
}

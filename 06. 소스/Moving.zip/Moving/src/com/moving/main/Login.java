package com.moving.main;

/**
 * 이용자가 로그인을 통해 회원/관리자 화면에 접근할 수 있도록 해줌
 * @author 박
 *
 */
public class Login {

	/**
	 * 로그인을 수행하는 메소드
	 */
	public void start() {
		
		String id = null, pw = null;
		boolean loop = true;
		boolean find = false;
		UI.clear();
		UI.title("로그인");
		System.out.println("0.상위 메뉴로");
		UI.line();
		
		try {
			id = UI.namedPause("회원 ID를 입력해주세요");
			
			if (id.equals("admin")) {
				while (loop) {
					pw = UI.namedPause("비밀번호를 입력해주세요");
					if (pw.equals(Main.memberList.get(0).getPassword())) {
						System.out.println("관리자님, 로그인을 환영합니다");
						
						Main.memberSeq = Main.memberList.get(0).getMemberSeq();
						Main.login = "0";
						
						UI.enterPause();
						loop = false;
					} else if (pw.equals("0")) {
						System.out.println("상위 메뉴로 돌아갑니다");
						UI.enterPause();
						loop = false;
					} else {
						System.out.println("비밀번호를 잘못 입력하셨습니다");
					}
				}//while
			}
			
			if (id.equals("0") || id.equals("admin")) {
				System.out.println("상위 메뉴로 돌아갑니다");
				UI.enterPause();
			} else {
				loop = true;
				find = false;
				for (int i=0;i<Main.memberList.size();i++) {
					
					if (id.equals(Main.memberList.get(i).getId())) {
						
						while (loop) {
							find = true;
							pw = UI.namedPause("비밀번호를 입력해주세요");
							
							if (pw.equals(Main.memberList.get(i).getPassword())) {
								String name = Main.memberList.get(i).getName();
								System.out.println();
								System.out.println(name+" 회원님, 로그인을 환영합니다");
								
								Main.memberSeq = Main.memberList.get(i).getMemberSeq();
								Main.login = "1";
								
								UI.enterPause();
								loop = false;
							} else if (pw.equals("0")) {
								System.out.println("상위 메뉴로 돌아갑니다");
								UI.enterPause();
								loop = false;
							} else {
								System.out.println("비밀번호를 잘못 입력하셨습니다");
							}
						}///while
					}//if equals
				}//for
				if (!find) {
					System.out.println("존재하지 않는 ID입니다");
					System.out.println("ID를 다시 확인해주세요");
					UI.enterPause();
				}
			}//else
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//start
}

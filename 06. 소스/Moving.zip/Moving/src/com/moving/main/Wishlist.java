package com.moving.main;

import com.moving.info.MovieInfo;

/**
 * 회원이 체크한 위시리스트를 목록으로 보여줌
 * @author 박
 *
 */
class Wishlist {
	
	/**
	 * 위시리스트 목록 보기를 수행하는 메소드 
	 */
	void start() {
	
		boolean loop = true;
		String member = Main.memberSeq;
		String seq = "", title = "", year = "", genre = "", star = "";
		int a = 0, b = 0;
		String sel = "";
		
		while (loop) {
			try {
				UI.clear();
				UI.title("나의 위시리스트 목록");
				System.out.println("영화 상세정보를 보려면 영화번호를 입력하세요.       0.상위 메뉴로");
				UI.line();
				System.out.println("[번호]   [제목]\t[연도]   [장르]    [별점]");
				
				for (int i=0;i<Main.wishlistList.size();i++) {
					if (member.equals(Main.wishlistList.get(i).getMemberSeq())) {
						seq = Main.movieList.get(Integer.parseInt(Main.wishlistList.get(i).getMovieSeq())-1).getSeq();
						title = Main.movieList.get(Integer.parseInt(Main.wishlistList.get(i).getMovieSeq())-1).getTitle();
						year = Main.movieList.get(Integer.parseInt(Main.wishlistList.get(i).getMovieSeq())-1).getStartDay();
						genre = Main.genreList.get(Integer.parseInt(Main.movieList.get(Integer.parseInt(Main.wishlistList.get(i).getMovieSeq())-1).getGenreSeq())).getGenre();
						a = Main.movieList.get(Integer.parseInt(Main.wishlistList.get(i).getMovieSeq())-1).getReviewerNum();
						b = Main.movieList.get(Integer.parseInt(Main.wishlistList.get(i).getMovieSeq())-1).getTotalScore();
						star = Getters.getStar(a, b);
						System.out.printf("%-4s      %-12.10s   \t%4.4s  \t%-6s  %s\n", seq, title, year, genre, star);
					}
				}//for
				
				UI.line();
				sel = UI.pause();
				
				if (sel.equals(Main.movieList.get(Integer.parseInt(sel)).getSeq())) {
					MovieInfo.info(sel);
				} else if (sel.equals("0")) {
					loop = false;
				}
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
		}//while
	}//start
}

package com.moving.main;

/**
 * 
 * @author 허영
 * 영화 추천에 쓰이는 UI를 모아놓은 클래스
 */
public class RecommendUI {
/**
 * 영화 추천 페이지 첫 UI
 */
	public void recommendStart1() {
		System.out.printf("--------------------------------------------------------------------------------\n"
				+ "\t\t\t\t상영 영화 추천"
				+ "\n--------------------------------------------------------------------------------\n"
				);

	}//recommendStart
	/**
	 * 영화 추천 페이지 메뉴
	 */
	public void recommendStart2() {
		UI.line();
		System.out.println("1.영화 상세 정보  2.다른 상영 영화  3.상영 종료 영화 추천 0.상위 메뉴\n");
	}
	/**
	 * 상영 종료 영화 페이지 UI
	 */
	public void oldMovie0() {
		
		UI.clear();
		UI.title("상영 종료 영화 추천");
		//System.out.println("위시리스트에 저장된 영화 정보를 바탕으로 추천됩니다.");
		System.out.println("추천 기준을 선택해주세요^^");
		
		System.out.println("1.감독\t2.배우\t3.년도\t4.장르\t5.위시리스트\t0.상위 메뉴");
		System.out.print("입력 > ");
	}
	
}

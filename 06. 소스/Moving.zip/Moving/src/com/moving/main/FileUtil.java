package com.moving.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

import com.moving.DTO.*;



public class FileUtil {
	
	/**
	 * @author 박
	 * 제어할 모든 리소스들을 외부에서 불러오는 메소드
	 */
	public static void load() {
		try {
			//actor.dat
			BufferedReader reader = new BufferedReader(new FileReader("data\\actor.dat"));
			String copy = "";

			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				ActorDTO actor = new ActorDTO();
				
				 if (temp[0].startsWith("\uFEFF")) {
		             temp[0] = temp[0].substring(1);
		          }
					 
				actor.setSeq(temp[0]);
				actor.setName(temp[1]);
				actor.setCountrySeq(temp[2]);
				actor.setBirth(temp[3]);
				actor.setProfile(temp[4]);
				Main.actorList.add(actor);
			} reader.close();
			
			reader = new BufferedReader(new FileReader("data\\actorFilmo.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				ActorFilmoDTO actorFilmo = new ActorFilmoDTO();
				actorFilmo.setActorSeq(temp[0]);
				actorFilmo.setMovieSeq(temp[1]);
				actorFilmo.setMovieRole(temp[2]);
				Main.actorFilmoList.add(actorFilmo);
			} 
			reader.close();
			
			reader = new BufferedReader(new FileReader("data\\award.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				AwardDTO award = new AwardDTO();
				award.setSeq(temp[0]);
				award.setAward(temp[1]);
				Main.awardList.add(award);
			} reader.close();
			
			reader = new BufferedReader(new FileReader("data\\awardRecord.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				AwardRecordDTO awardRecord = new AwardRecordDTO();
				awardRecord.setDirectorSeq(temp[0]);
				awardRecord.setAwardSeq(temp[1]);
				awardRecord.setPrizeTypeSeq(temp[2]);
				Main.awardRecordList.add(awardRecord);
			} reader.close();

			
			reader = new BufferedReader(new FileReader("data\\company.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				CompanyDTO company = new CompanyDTO();
				company.setCompanySeq(temp[0]);
				company.setCompany(temp[1]);
				Main.companyList.add(company);
			} reader.close();
		
			
			reader = new BufferedReader(new FileReader("data\\country.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				CountryDTO country = new CountryDTO();
				country.setSeq(temp[0]);
				country.setCountry(temp[1]);
				Main.countryList.add(country);
			} reader.close();

			//오류
			reader = new BufferedReader(new FileReader("data\\director.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				DirectorDTO director = new DirectorDTO();
				
				 if (temp[1].startsWith("\uFEFF")) {
		             temp[1] = temp[1].substring(temp[1].length()-1);
		          }
				 
				director.setSeq(temp[0]);
				director.setName(temp[1]);
				director.setCountrySeq(temp[2]);
				director.setBirthday(temp[3]);
				director.setInfo(temp[4]);
				Main.directorList.add(director);

			} reader.close();

			reader = new BufferedReader(new FileReader("data\\directorFilmo.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				DirectorFilmoDTO directorFilmo = new DirectorFilmoDTO();

				directorFilmo.setDirectorSeq(temp[0]);
				directorFilmo.setMovieSeq(temp[1]);
				Main.directorFilmoList.add(directorFilmo);
			} reader.close();
		
			reader = new BufferedReader(new FileReader("data\\genre.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				GenreDTO genre = new GenreDTO();
				
				 if (temp[0].startsWith("\uFEFF")) {
		             temp[0] = temp[0].substring(1);
		          }
					 
				 if (temp[1].startsWith("\uFEFF")) {
					 temp[1] = temp[1].substring(temp[1].length()-1);
			     }
				 
				genre.setSeq(temp[0]);
				genre.setGenre(temp[1]);
				Main.genreList.add(genre);
			} reader.close();
			
			reader = new BufferedReader(new FileReader("data\\grade.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				GradeDTO grade = new GradeDTO();
				grade.setSeq(temp[0]);
				grade.setGrade(temp[1]);
				Main.gradeList.add(grade);
			} reader.close();

			reader = new BufferedReader(new FileReader("data\\keyword.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				KeywordDTO keyword = new KeywordDTO();
				keyword.setSeq(temp[0]);
				keyword.setKeyword(temp[1]);
				Main.keywordList.add(keyword);
			} reader.close();

			reader = new BufferedReader(new FileReader("data\\local.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				LocalDTO local = new LocalDTO();
				
				 if (temp[0].startsWith("\uFEFF")) {
		             temp[0] = temp[0].substring(1);
		          }
				 
				local.setLocalSeq(temp[0]);
				

				local.setLocal(temp[1]);
				Main.localList.add(local);
			} reader.close();

			//오류
			reader = new BufferedReader(new FileReader("data\\member.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				MemberDTO member = new MemberDTO();
				
				
				member.setMemberSeq(temp[0]);
				
				member.setId(temp[1]);
				member.setPassword(temp[2]);
				member.setName(temp[3]);
				member.setBirthday(temp[4]);
				member.setEmail(temp[5]);
				member.setTel(temp[6]);
				Main.memberList.add(member);
			} reader.close();

			
			//이상한오류
			reader = new BufferedReader(new FileReader("data\\movie.dat"));
			while ((copy = reader.readLine()) != null) {
			
				String[] temp = copy.split("\\|");
				MovieDTO movie = new MovieDTO();
				 if (temp[0].startsWith("\uFEFF")) {
		             temp[0] = temp[0].substring(temp[0].length() - 1);
		          }
				 
				 if (temp[1].startsWith("\uFEFF")) {
		             temp[1] = temp[1].substring(temp[1].length() - 1);
		          }
				 
				 if (temp[2].startsWith("\uFEFF")) {
		             temp[2] = temp[2].substring(temp[2].length() - 1);
		          }
				 
				 if (temp[7].startsWith("\uFEFF")) {
		             temp[7] = temp[7].substring(temp[7].length() - 1);
		          }
				 
				 
				movie.setSeq(temp[0]);
				movie.setTitle(temp[1]);
				movie.setStartDay(temp[2]);
				movie.setGenreSeq(temp[3]);
				movie.setCountrySeq(temp[4]);
				movie.setAudience(Integer.parseInt(temp[5]));
				movie.setGradeSeq(temp[6]);
				movie.setState(temp[7]);
				movie.setTotalScore(Integer.parseInt(temp[8]));
				movie.setReviewerNum(Integer.parseInt(temp[9]));
				movie.setTrailer(temp[10]);
				movie.setSynopsis(temp[11]);
				Main.movieList.add(movie);
			} reader.close();

			reader = new BufferedReader(new FileReader("data\\movieKey.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				MovieKeyDTO movieKey = new MovieKeyDTO(); 
				movieKey.setMovieSeq(temp[0]);
				movieKey.setKeywordSeq(temp[1]);
				Main.movieKeyList.add(movieKey);
			} reader.close();
	
			//자료없음
			reader = new BufferedReader(new FileReader("data\\onscreen.dat"));
			while ((copy = reader.readLine()) != null) {
				 
				String[] temp = copy.split("\\|");
				 if (temp[0].startsWith("\uFEFF")) {
		             temp[0] = temp[0].substring(1);
		          }
				 
				OnscreenDTO onscreen = new OnscreenDTO();
				onscreen.setOnscreenSeq(temp[0]);
				onscreen.setCompanySeq(temp[1]);
				onscreen.setLocalSeq(temp[2]);
				onscreen.setMovieSeq(temp[3]);
				onscreen.setDay(temp[4]);
				onscreen.setTimeSeq(temp[5]);
				onscreen.setEvent(temp[6]);
				Main.onscreenList.add(onscreen);
			} reader.close();
			
			reader = new BufferedReader(new FileReader("data\\price.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				PriceDTO price = new PriceDTO();
				
				 if (temp[0].startsWith("\uFEFF")) {
		             temp[0] = temp[0].substring(1);
		          }
				 
				price.setPriceSeq(temp[0]);
				price.setPriceType(temp[1]);
				price.setPrice(Integer.parseInt(temp[2]));
				Main.priceList.add(price);
			} 
			reader.close();
				
			reader = new BufferedReader(new FileReader("data\\prizeType.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				PrizeTypeDTO prizeType = new PrizeTypeDTO();
				prizeType.setSeq(temp[0]);
				prizeType.setPrizeType(temp[1]);
				Main.prizeTypeList.add(prizeType);
			} reader.close();
			
	
			reader = new BufferedReader(new FileReader("data\\role.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				RoleDTO role = new RoleDTO();
				role.setSeq(temp[0]);
				role.setRole(temp[1]);
				Main.roleList.add(role);
			} reader.close();
	
			//자료없음
			reader = new BufferedReader(new FileReader("data\\ticket.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				TicketDTO ticket = new TicketDTO();
				ticket.setMemberSeq(temp[0]);
				ticket.setOnscreenSeq(temp[1]);
				ticket.setSeat(temp[2]);
				Main.ticketList.add(ticket);
			} reader.close();
			
			reader = new BufferedReader(new FileReader("data\\time.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				TimeDTO time = new TimeDTO();
				time.setTimeSeq(temp[0]);
				time.setTime(temp[1]);
				Main.timeList.add(time);
			} reader.close();
	
			reader = new BufferedReader(new FileReader("data\\wishlist.dat"));
			while ((copy = reader.readLine()) != null) {
				String[] temp = copy.split("\\|");
				WishlistDTO wishlist = new WishlistDTO();
				wishlist.setMemberSeq(temp[0]);
				wishlist.setMovieSeq(temp[1]);
				Main.wishlistList.add(wishlist);
			} 
			reader.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//load
	
	/**
	 * @author 허영
	 * 영화관련 내용을 저장하는 메소드.
	 */

	public static void movieSave() {
		
			try {
				BufferedWriter writer = null;//한번만 만들면 됨.
				
				writer = new BufferedWriter(new FileWriter("data\\movie.dat"));//덮어쓰기
				
				for(MovieDTO movie : Main.movieList ) {
					//MovieDTO 객체 1개 - 텍스트 파일의 1줄
					String line = String.format("%s|%s|%s|%s|%s|%d|%s|%s|%d|%d|%s|%s", 
												movie.getSeq(),
												movie.getTitle(), 
												movie.getStartDay(),
												movie.getGenreSeq(), 
												movie.getCountrySeq(), 
												movie.getAudience(),
												movie.getGradeSeq(), 
												movie.getState(), 
												movie.getTotalScore(),
												movie.getReviewerNum(), 
												movie.getTrailer(), 
												movie.getSynopsis()) ;
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//genre.dat
				writer = new BufferedWriter(new FileWriter("data\\genre.dat"));//덮어쓰기
				
				for(GenreDTO genre : Main.genreList) {
					String line = String.format("%s|%s", 
												genre.getSeq(), genre.getGenre() );
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//keyword.dat
				writer = new BufferedWriter(new FileWriter("data\\keyword.dat"));//덮어쓰기
				
				for(KeywordDTO keyword : Main.keywordList){
					String line = String.format("%s|%s", 
												keyword.getSeq(), keyword.getKeyword() );
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//movieKey.dat
				writer = new BufferedWriter(new FileWriter("data\\movieKey.dat"));//덮어쓰기
				
				for(MovieKeyDTO movieKey : Main.movieKeyList) {
					String line = String.format("%s|%s", 
												movieKey.getMovieSeq(), movieKey.getKeywordSeq() );
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//grade.dat
				writer = new BufferedWriter(new FileWriter("data\\grade.dat"));//덮어쓰기
				
				for(GradeDTO grade : Main.gradeList) {
					String line = String.format("%s|%s", 
												grade.getSeq(), grade.getGrade() );
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//country.dat
				writer = new BufferedWriter(new FileWriter("data\\country.dat"));//덮어쓰기
				
				for(CountryDTO country : Main.countryList) {
					String line = String.format("%s|%s", 
												country.getSeq(), country.getCountry());
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
			} catch (Exception e) {
			}
		
		
		
		
	}
	
	
	/**
	 * @author 해나
	 * 영화관련데이터들 저장하는 메소드
	 */

	public static void cinemaSave() {
	
		
		try {
		
			BufferedWriter writer = null;
			
			writer = new BufferedWriter(new FileWriter("data\\onscreen.dat"));

			for (OnscreenDTO o : Main.onscreenList) {
				String line = String.format("%s|%s|%s|%s|%s|%s|%s"
																, o.getOnscreenSeq()
																, o.getCompanySeq()
																, o.getLocalSeq()
																, o.getMovieSeq()
																, o.getDay()
																, o.getTimeSeq()
																, o.getEvent());
				writer.write(line);
				writer.newLine();
	
			}		
			writer.close();
			
			
			writer = new BufferedWriter(new FileWriter("data\\company.dat"));

			for (CompanyDTO c : Main.companyList) {
				String line = String.format("%s|%s"
																, c.getCompanySeq()
																, c.getCompany());
				writer.write(line);
				writer.newLine();
			}
			writer.close();

			writer = new BufferedWriter(new FileWriter("data\\local.dat"));
			
			for(LocalDTO l : Main.localList) {
				String line = String.format("%s|%s", l.getLocalSeq(), l.getLocal());
				
				writer.write(line);
				writer.newLine();
			}
			writer.close();
			

			writer = new BufferedWriter(new FileWriter("data\\time.dat"));
			
			for(TimeDTO t : Main.timeList) {
				String line = String.format("%s|%s", t.getTimeSeq(), t.getTime());
				
				writer.write(line);
				writer.newLine();
			}
			writer.close();
			
			writer = new BufferedWriter(new FileWriter("data\\price.dat"));


			
			for(PriceDTO p : Main.priceList) {
				String line = String.format("%s|%s|%d"
																, p.getPriceSeq()
																, p.getPriceType()
																, p.getPrice());
				writer.write(line);
				writer.newLine();
			}
			writer.close();
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}	
	}
	
	
	/**
	 * @author 허영
	 * 인물관련 내용을 저장하는 메소드.
	 */

	public static void artistSave() {
		
			try {
				BufferedWriter writer = null;//한번만 만들면 됨.
				
				writer = new BufferedWriter(new FileWriter("data\\director.dat"));//덮어쓰기
				
				for(DirectorDTO director : Main.directorList ) {
					String line = String.format("%s|%s|%s|%s|%s", 
												director.getSeq(),director.getName(), director.getCountrySeq(), 
												director.getBirthday(), director.getInfo());
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//directorFilmo.dat
				writer = new BufferedWriter(new FileWriter("data\\directorFilmo.dat"));//덮어쓰기
				
				for(DirectorFilmoDTO directorFilmo : Main.directorFilmoList) {
					String line = String.format("%s|%s", 
												directorFilmo.getDirectorSeq(), directorFilmo.getMovieSeq());
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//awardRecord.dat
				writer = new BufferedWriter(new FileWriter("data\\awardRecord.dat"));//덮어쓰기
				
				for(AwardRecordDTO awardRecord : Main.awardRecordList){
					String line = String.format("%s|%s|%s", 
												awardRecord.getDirectorSeq(), awardRecord.getAwardSeq(), 
												awardRecord.getPrizeTypeSeq());
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//prizeType.dat
				writer = new BufferedWriter(new FileWriter("data\\prizeType.dat"));//덮어쓰기
				
				for(PrizeTypeDTO prizeType : Main.prizeTypeList) {
					String line = String.format("%s|%s", 
												prizeType.getSeq(), prizeType.getPrizeType() );
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//award.dat
				writer = new BufferedWriter(new FileWriter("data\\award.dat"));//덮어쓰기
				
				for(AwardDTO award : Main.awardList) {
					String line = String.format("%s|%s", 
												award.getSeq(), award.getAward() );
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//actor.dat
				writer = new BufferedWriter(new FileWriter("data\\actor.dat"));//덮어쓰기
				
				for(ActorDTO actor : Main.actorList) {
					String line = String.format("%s|%s|%s|%s|%s", 
												actor.getSeq(), actor.getName(),
												actor.getCountrySeq(), actor.getBirth(),
												actor.getProfile());
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//role.dat
				writer = new BufferedWriter(new FileWriter("data\\role.dat"));//덮어쓰기
				
				for(RoleDTO role : Main.roleList) {
					String line = String.format("%s|%s", 
												role.getSeq(), role.getRole());
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
				//actorFilmo.dat
				writer = new BufferedWriter(new FileWriter("data\\actorFilmo.dat"));//덮어쓰기
				
				for(ActorFilmoDTO actorFilmo : Main.actorFilmoList) {
					String line = String.format("%s|%s|%s", 
												actorFilmo.getActorSeq(), actorFilmo.getMovieSeq()
												, actorFilmo.getMovieRole());
					
					writer.write(line);
					writer.newLine();
				}
				
				writer.close();
				
			} catch (Exception e) {
			}

	}
	
	 public static void memberSave(){
	      try {
	         
	         BufferedWriter writer = null; 
	               
	         writer = new BufferedWriter(new FileWriter("data\\member.dat"));
	         
	         for (MemberDTO member : Main.memberList){
	            
	            String line = String.format("%s|%s|%s|%s|%s|%s|%s"
	            									,member.getMemberSeq()
	                                                ,member.getId()
	                                                ,member.getPassword()
	                                                ,member.getName()
	                                                ,member.getBirthday()
	                                                ,member.getEmail()
	                                                ,member.getTel());
	            writer.write(line);
	            writer.newLine();
	         }
	         writer.close();
	         
	         writer = new BufferedWriter(new FileWriter("data\\ticket.dat"));
	         
	         for (TicketDTO ticket : Main.ticketList){
	            String line = String.format("%s|%s|%s"
	            							,ticket.getMemberSeq()
	                                       ,ticket.getOnscreenSeq()
	                                       ,ticket.getSeat());
	            writer.write(line);
	            writer.newLine();
	         }
	         writer.close();
	         
	         writer = new BufferedWriter(new FileWriter("data\\wishlist.dat"));
	         
	         for (WishlistDTO wishlist : Main.wishlistList){
	            String line = String.format("%s|%s",wishlist.getMemberSeq(),
	                                       wishlist.getMovieSeq());
	            writer.write(line);
	            writer.newLine();
	         }
	         writer.close();
	         
	      } catch (Exception e) {
	         System.out.println(e.toString());
	      }
	   }
	   

}








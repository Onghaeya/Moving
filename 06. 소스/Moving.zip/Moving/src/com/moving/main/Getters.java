package com.moving.main;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

import com.moving.DTO.ActorDTO;
import com.moving.DTO.ActorFilmoDTO;
import com.moving.DTO.AwardDTO;
import com.moving.DTO.AwardRecordDTO;
import com.moving.DTO.CountryDTO;
import com.moving.DTO.DirectorDTO;
import com.moving.DTO.DirectorFilmoDTO;
import com.moving.DTO.GenreDTO;
import com.moving.DTO.GradeDTO;
import com.moving.DTO.MemberDTO;
import com.moving.DTO.MovieDTO;
import com.moving.DTO.PrizeTypeDTO;
import com.moving.DTO.WishlistDTO;



public class Getters {
	
	protected Scanner scan;

	public Getters() {
		scan = new Scanner(System.in);
	}
	/**
	 * 영화의 제목을 찾는 메소드
	 * @param movieSeq 영화 번호
	 * @return 영화 제목
	 */
	public static String getTitle(String movieSeq) {
		for(MovieDTO m : Main.movieList) {
			if(m.getSeq().equals(movieSeq)) {
				return m.getTitle();
			}
		}
		return "없음";
	}
	
	
	/**
	 * 영화 관객수를 찾는 메소드
	 * @param movieSeq 영화번호
	 * @return int 영화관객수
	 */
	public static int getAudience(String movieSeq) {
		
		for(MovieDTO m : Main.movieList) {
			if(m.getSeq().equals(movieSeq)) {
				return m.getAudience();
			}
		}
		return 0;
	}
	
	
	
	/**
	 * 영화의 별점을 ★로 바꿔주는 메소드
	 * @param reviewerNum 평점을 준 사람의 수
	 * @param totalScore 총 점수
	 * @return 최고 5개의 별 모양을 반환한다.
	 */
		public static String getStar(int reviewerNum, int totalScore) {

			String star = "";
		
			if(reviewerNum > 0) {
			
				for(int i=0; i<totalScore/reviewerNum; i++) {
					star += "★";
				}
				for(int i=0; i<5-totalScore/reviewerNum; i++) {
					star += "☆";
				}
				return star;
		
			} else {
				return "-";
			}
		}
		
		/**
		 * 감독의 이름을 반환하는 메소드
		 * @param movieSeq 영화 번호
		 * @return 감독의 이름
		 */
		public static String getDirector(String movieSeq) {
			
			String directorSeq = "";
			
			for(DirectorFilmoDTO d : Main.directorFilmoList) {
				if(d.getMovieSeq().equals(movieSeq)) {
					directorSeq = d.getDirectorSeq();
					break;	
				}
			}
			
			for(DirectorDTO d : Main.directorList) {
				if(d.getSeq().equals(directorSeq)) {
					return d.getName();
				}
			}
			return "미상";
		}

		
		/**
		 * 날짜에서 연도만을 추출하는 메소드
		 * @param date 0000-00-00 형식의날짜
		 * @return 연도만을 반환
		 */
		public static int getYear(String date) {
			
			String[] splitDate = date.split("\\-");
			
			return Integer.parseInt(splitDate[0]);	
			
		}
		
		/**
		 * 영화의 장르를 얻기 위한 메소드
		 * @param genreSeq 장르 번호
		 * @return 해당 영화의 장르를 반환
		 */
		public static String getGenre(String genreSeq) {
			
			for(GenreDTO g : Main.genreList) {
				if(g.getSeq().equals(genreSeq)) {
					return g.getGenre();
				}
			}
			
			return "기타";	
		}
		
		
		/**
		 * 주연배우 목록을 얻는 메소드
		 * @param movieSeq 영화 번호
		 * @return 주연배우 목록을 반환
		 */
		public static ArrayList<String> getAActors(String movieSeq) {
			
			ArrayList<String> actorsList = new ArrayList<String>();
			
			for(ActorFilmoDTO a : Main.actorFilmoList) {
				//해당 영화와 같은 영화 찾기
				if(a.getMovieSeq().equals(movieSeq)) {
					//주연배우만
					if(a.getMovieRole().equals("A")) {
						actorsList.add(a.getActorSeq());
					}
				}
			}
			
			for(int i=0; i<actorsList.size(); i++) {
				for(ActorDTO a : Main.actorList) {
					
					//시퀀스가 같은 애들을 찾음
					if(actorsList.get(i).equals(a.getSeq())) {	
						actorsList.set(i, a.getName());	//이름으로 바꿔서 저장
						continue;
					}
				}
			}
			
			return actorsList;
		}
		
		
		/**
		 * 조연 배우 목록을 얻는 메소드
		 * @param movieSeq 영화 번호
		 * @return 조연배우 목록 반환
		 */
		public static ArrayList<String> getBActors(String movieSeq) {		
			ArrayList<String> actorsList = new ArrayList<String>();
			
			for(ActorFilmoDTO a : Main.actorFilmoList) {
				//해당 영화와 같은 영화 찾기
				if(a.getMovieSeq().equals(movieSeq)) {
					//조연배우만
					if(a.getMovieRole().equals("B")) {
						actorsList.add(a.getActorSeq());
					}
				}
			}
			
			for(int i=0; i<actorsList.size(); i++) {
				for(ActorDTO a : Main.actorList) {
					
					//시퀀스가 같은 애들을 찾음
					if(actorsList.get(i).equals(a.getSeq())) {	
						actorsList.set(i, a.getName());	//이름으로 바꿔서 저장
						continue;
					}
				}
			}
			
			return actorsList;
		}

		
		/**
		 * 영화의 관람 등급을 얻기 위한 메소드
		 * @return 해당 영화의 등급을 반환
		 */
		public static String getGrade(String gradeSeq) {
			
			for(GradeDTO g : Main.gradeList) {
				if(g.getSeq().equals(gradeSeq)) {
					return g.getGrade();
				}
			}
			return "-";
		}
		
		
		/**
		 * 나라를 반환하는 메소드
		 * @param countrySeq 나라 식별 번호
		 * @return 나라 이름을 반환
		 */
		public static String getCountry(String countrySeq) {
			
			for(CountryDTO c : Main.countryList) {
				if(c.getSeq().equals(countrySeq)) {
					return c.getCountry();
				}
			}
			return " ";
		
		}
		
		/**
		 * 해당 영화가 위시리스트에 존재하는지 여부를 알려줌
		 * @param movieSeq 영화의 식별번호
		 * @return 존재하면 true, 존재하지않으면 false
		 */
		public static boolean isInWishlist(String movieSeq) {
			for(WishlistDTO w : Main.wishlistList) {
				if(w.getMemberSeq().equals(Main.memberSeq) 
						&& w.getMovieSeq().equals(movieSeq)) {
					return true;
				}
			}
			return false;
		}
		
		/**
		 * 나이를 계산하는 메소드
		 * @param birthday 생일
		 * @return 나이
		 */
		public int getAge(String birthday) {
			int year = getYear(birthday);
			
			Calendar c = Calendar.getInstance();
			int thisYear = c.get(c.YEAR);
			
			return thisYear - year + 1;
		} 
		
		
		/**
		 * 영화인의 대표작을 구하는 메소드
		 * @param seq 영화인의 식별번호
		 * @param mode 0==감독, 1==배우
		 * @return 대표작을 반환
		 */
		public String getMajorWork(String seq, int mode) {
			
			String movie1 = "";
			int movieAudience1 = 0;
			
			String movie2 = "";
			int movieAudience2 = 0;
			//감독 대표작 검색
			if(mode == 0) {
		
				for(DirectorFilmoDTO d : Main.directorFilmoList) {	
					if(d.getDirectorSeq().equals(seq)) {
						
						movie2 = d.getMovieSeq();
						
						for(MovieDTO m : Main.movieList) {
							if(m.getSeq().equals(d.getMovieSeq())) {
								movieAudience2 = m.getAudience();
							}	
						}
						
						if(movieAudience1 < movieAudience2) {
							movieAudience1 = movieAudience2;
							movie1 = movie2;
						}
					}					
				}
				
			} else {
				//배우 대표작 검색
				for(ActorFilmoDTO d : Main.actorFilmoList) {	
					if(d.getActorSeq().equals(seq)) {
						
						movie2 = d.getMovieSeq();
						
						for(MovieDTO m : Main.movieList) {
							if(m.getSeq().equals(d.getMovieSeq())) {
								movieAudience2 = m.getAudience();
							}	
						}
						
						if(movieAudience1 < movieAudience2) {
							movieAudience1 = movieAudience2;
							movie1 = movie2;
						}
					}					
				}
			}
			
			return getTitle(movie1);
		}
		
		/**
		 * 주연인지 조연인지 알려주는 메소드
		 * @param "A" == 주연, "B" == 조연
		 */
		public static String getRole(String s) {
			
			String role = "";
			
			if(s.equals("A")) {
				role = "주연";
			} else {
				role = "조연";
			}	
			return role;
		}
		
		/**
		 * 영화인의 필모그래피 구하는 메소드
		 * @param artistSeq 배우 혹은 감독 번호
		 * @param mode 0==감독, 1==배우
		 * @return 작품 목록
		 */
	public static ArrayList<String> getWorks(String artistSeq, int mode) {
		
		ArrayList<String> worksList = new ArrayList<String>();
		
		if(mode == 0) {
			
			for(DirectorFilmoDTO d : Main.directorFilmoList) {
				//해당 영화와 같은 영화 찾기
				if(d.getDirectorSeq().equals(artistSeq)) {	
					worksList.add(getTitle(d.getMovieSeq()));
				}
			}
			
			return worksList;	
					
		} else {
			for(ActorFilmoDTO d : Main.actorFilmoList) {
				//해당 영화와 같은 영화 찾기
				if(d.getActorSeq().equals(artistSeq)) {	
					worksList.add(getTitle(d.getMovieSeq())+ " (" + getRole(d.getMovieRole()) + ")");
				}
			}
			
			return worksList;
		}
	
	}
	
	/**
	 * 감독의 수상내역을 구하는 메소드
	 * @param artistSeq 감독의 번호
	 * @return ArrayList<String>
	 */
	public static ArrayList<String> getPrizeList(String artistSeq) {
		
		ArrayList<String> prizeList = new ArrayList<String>();
		
		for(AwardRecordDTO a : Main.awardRecordList) {
			if(a.getDirectorSeq().equals(artistSeq)) {
				prizeList.add(getPrizeName(a.getAwardSeq(), a.getPrizeTypeSeq()));
			}
		}
		
		return prizeList;
		
	}

	
	/**
	 * 영화제와 상의 이름을 구하는 메소드
	 * @param awardSeq 영화제 식별번호
	 * @param prizeTypeSeq 상 종류 식별 번호
	 * @return String 영화제 + 상 이름
	 */
	public static String getPrizeName(String awardSeq, String prizeTypeSeq) {
		
		String prize = "";
		for(AwardDTO a : Main.awardList) {
			if(a.getSeq().equals(awardSeq)) {
				prize = a.getAward();
				break;
			}
		}
		
		for(PrizeTypeDTO p : Main.prizeTypeList) {
			if(p.getSeq().equals(prizeTypeSeq)) {
				prize += " " + p.getPrizeType();
				break;
			}
		}
		
		return prize;
	}
	
	public String getState(String movieSeq) {
		
		String state = "";
		
		for(MovieDTO m : Main.movieList) {
			if(m.getSeq().equals(movieSeq)) {
				state = m.getState();
				break;
			}
		}

		if(state.equals("0")) {
			state = "미상영";
		} else if(state.equals("1")) {
			state = "상영중";
		}
		
		return state;
	}

	public String getName(String memberSeq) {
		
		String name = "";
		
		for(MemberDTO m : Main.memberList) {
			if(m.getMemberSeq().equals(memberSeq)) {
				name = m.getName();
			}
		}
		return name;
	}
	

	
	public static String devideLine(String line) {
		
		String line2 = "";
		for(int i=0; i<line.length()/40; i++) {
			 line2 += line.substring(40 * i, 40 * (i + 1)) + "\n";
		}
		
		line2 += line.substring(line.length()/40 * 40);
		
		return line2;
		
	}

}





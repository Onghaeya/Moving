package com.moving.main;

public class MyPage {

}

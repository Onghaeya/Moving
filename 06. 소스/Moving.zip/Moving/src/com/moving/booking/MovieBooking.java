package com.moving.booking;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.MovieDTO;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.SearchUI;

/**
 * 영화별 예매
 * @author 해나
 *
 */
public class MovieBooking extends CinemaGetters {
	
	/**
	 * 영화별 예매 선택 시 영화 목록을 출력하는 메소드
	 */
	public void movieBooking() {
		
		boolean loop = true; 
		while(loop) {
			
			ArrayList<String> seqList = new ArrayList<String>();
			Scanner scan = new Scanner(System.in);
			SearchUI.getBookingListHeader();
			System.out.println();
			
			for(MovieDTO m : Main.movieList) {
				//[영화번호]\t[제목]\t\t[연도]\t[장르]\t[감독]\t\t[별점]
				//TODO 출력 예쁘게 수정
				if(m.getState().equals("1")) {
					System.out.printf("%4s\t%-5.5s  \t%-8s\t%-7.7s\t%s\t%.2f%%\n"
													, m.getSeq()
													, m.getTitle()
													, getGenre(m.getGenreSeq())
													, getDirector(m.getSeq())
													, getStar(m.getReviewerNum(), m.getTotalScore())
													, countVeiwers(m.getSeq()));
					
					seqList.add(m.getSeq());
				}
			}
					
					System.out.println();
					System.out.print("예매할 영화 번호 입력 > ");
					String movieSeq = scan.nextLine();
					if(movieSeq.equals("0")) {
						return;
					} else if(seqList.contains(movieSeq)) {
						BookingService.choice.setMovieSeq(movieSeq);
						loop = false;
					} else {
						SearchUI.inputError();
					}	

		}
	}
}

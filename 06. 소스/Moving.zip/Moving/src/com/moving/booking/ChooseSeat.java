package com.moving.booking;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.PriceDTO;
import com.moving.DTO.TicketDTO;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.SearchUI;
/**
 * 예매 좌석 선택
 * @author 해나
 *
 */
public class ChooseSeat extends CinemaGetters {
	
	/**
	 * 예매 좌석 선택 메소드
	 */
	public void chooseSeat() {
		
		Scanner scan = new Scanner(System.in);
		int[] seatList = new int[150];
	
		
		char c = 'A';
		int num = 0;
		
		for(TicketDTO t : Main.ticketList) {
			if((t.getOnscreenSeq().equals(BookingService.choice.getOnscreenSeq()))) {
				seatList[Integer.parseInt(t.getSeat())] = 1;
			} else {
				seatList[Integer.parseInt(t.getSeat())] = 0;
			}
		}
		
		
		System.out.println("                            SCREEN\n");
		for(int i=0; i<seatList.length; i++) {
			
			if((i + 1) % 15 == 1) {
				System.out.print(c + "  ");
				c++;
			}
		
			if(seatList[i] == 0) {
				System.out.print("□  ");
			} else {
				System.out.print("■  ");
			}
			
			if((i + 1) % 15 == 0) {

				System.out.println();
			}

		}
		
		System.out.println();
			
		for(int i=0; i<15; i++) {
			System.out.printf("%4d", i + 1);
		}
		System.out.println();
		
		//TODO 유효성 검사
		System.out.println();
		ArrayList<String> seatNameList = new ArrayList<String>();
		ArrayList<String> seatTypeList = new ArrayList<String>();
		
		System.out.print("예매할 좌석 수 > ");
		num = Integer.parseInt(scan.nextLine());
		
		String seatName = "";
	
		for(int i=0; i<num; i++) {
			boolean loop = true;
			while(loop) {
		
				System.out.print("좌석입력 (ex. A3) > ");
				seatName = scan.nextLine();
				
				if(isSeatEmpty(seatName)) {
					loop = false;
				} else {
					System.out.println();
					System.out.println("예약된 좌석입니다.");
					UI.enterPause();
				}
			}
			
			for(PriceDTO p : Main.priceList) {
				System.out.printf("%s. %s    ", p.getPriceSeq(), p.getPriceType());			
			}
			System.out.println();
			
			boolean loop2 = true;
			String seatType = "";
			
			while(loop2) {
				System.out.print("종류 입력(번호) > ");
				seatType = scan.nextLine();
				if(Integer.parseInt(seatType) <= Main.priceList.size()) {
					loop2 = false;
				} else {
					SearchUI.inputError();
				}
				System.out.println();
			}
			//getSeatNum(seatName);
			seatNameList.add(seatName);
			seatTypeList.add(seatType);
		}
		
		check(seatNameList, seatTypeList);
	}

	/**
	 * 사용자의 선택을 마지막으로 확인하는 메소드
	 * @param seatNameList 좌석 이름 목록
	 * @param seatTypeList 좌석 타입 목록
	 */
	public void check(ArrayList<String> seatNameList, ArrayList<String> seatTypeList) {
		System.out.println("※ 예매확인");
		System.out.printf("%s\n< %s >\n%s  %s \n%s  \n"
										, getCinema(BookingService.choice.getLocalSeq()
												, BookingService.choice.getCompanySeq())
										, getTitle(BookingService.choice.getMovieSeq())
										, getYear(BookingService.choice.getDay()) + "년"
										, getKoreanDate(BookingService.choice.getDay())
										, getTime(BookingService.choice.getTimeSeq()));
			
		for(int i=0; i<seatNameList.size(); i++) {
			System.out.print(seatNameList.get(i));
			System.out.println(" (" + getPriceType(seatTypeList.get(i)) + ")");
		}
		
		System.out.println();
		System.out.println("예매를 진행 하시겠습니까? (Y/N)");
		System.out.print("입력 > ");
		String answer = scan.nextLine();
		
		if(answer.equals("N")) {
			return;
		} else if(answer.equals("Y")) {
			TicketPay p = new TicketPay();
			p.pay(seatNameList, seatTypeList);
		} else {
			SearchUI.inputError();
		}
	}
	
	/**
	 * 해당 좌석이 비었는지 확인하는 메소드
	 * @param seatName 좌석 이름
	 * @return 비었으면 true 아니면 false
	 */
	public boolean isSeatEmpty(String seatName) {

		for(TicketDTO t : Main.ticketList) {
			if(BookingService.choice.getOnscreenSeq().equals(t.getOnscreenSeq())
					&& getSeatNum(seatName) == Integer.parseInt(t.getSeat())) {
				return false;
			}
		}
		return true;
	}
	
	
}

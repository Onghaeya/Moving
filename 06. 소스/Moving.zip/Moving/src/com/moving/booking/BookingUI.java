package com.moving.booking;

import com.moving.main.UI;

/**
 * 예매 관련 UI
 * @author SIST
 *
 */
public class BookingUI {
	
	/**
	 * 예매 첫 페이지의 메뉴
	 */
	public static void getBookingMenu() {
		System.out.println("1. 지역별 예매\t2. 영화별 예매\t0. 상위메뉴로");
		UI.line();
	}
	
	/**
	 * 예매 결제 메뉴
	 */
	public static void getPayMenu() {
		System.out.println("1. 무통장 입금\t2. 휴대폰 결제\t3. 카드 결제");
		UI.line();
	}
	
	/**
	 * 예매 확인의 헤더
	 */
	public static void getTicket() {
		System.out.println("===========================");
		System.out.println("             *TICKET*");
		System.out.println("===========================");
		
	}
}

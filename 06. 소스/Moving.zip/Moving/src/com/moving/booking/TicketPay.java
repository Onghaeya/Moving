package com.moving.booking;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.TicketDTO;
import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.search.SearchUI;

/**
 * 예매 결제 
 * @author 해나
 *
 */
public class TicketPay extends CinemaGetters {
	
	/**
	 * 예매내역을 결제 방법 선택 및 지불
	 * @param seatNameList 선택한 좌석 이름 목록
	 * @param seatTypeList 선택한 좌석 타입 목록
	 */
	public void pay(ArrayList<String> seatNameList, ArrayList<String> seatTypeList) {
		Scanner scan = new Scanner(System.in);
		int price = 0;
		
		for(String s : seatTypeList) {
			price += getPrice(s);
		}
		
		BookingUI.getPayMenu();
		System.out.print("입력 > ");
		String sel = scan.nextLine();
		
		if(sel.equals("1")) {
			System.out.printf("국민 0000-000-00000으로 %d원 입금하세요.\n"
											, price);
		} else if(sel.equals("2")) {
			System.out.println("휴대폰 번호 입력 (숫자만): ");
			scan.nextLine();
		} else if(sel.equals("3")) {
			System.out.println("카드 번호 입력 (숫자만) : ");
		} else {
			SearchUI.inputError();
		}
			
		SearchUI.pause();
		
		 for(int i=0; i<seatNameList.size(); i++) {
			 
			TicketDTO temp = new TicketDTO();
			temp.setMemberSeq(Main.memberSeq);
			temp.setOnscreenSeq(BookingService.choice.getOnscreenSeq());
			temp.setSeat(getSeatNum(seatNameList.get(i)) +  "");
			
			Main.ticketList.add(temp);
		 }
		
		FileUtil.memberSave();
		System.out.println("예매가 완료되었습니다.");
		SearchUI.pause();
	}
}

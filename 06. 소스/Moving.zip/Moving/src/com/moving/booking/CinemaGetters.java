package com.moving.booking;

import java.util.ArrayList;

import com.moving.DTO.CompanyDTO;
import com.moving.DTO.LocalDTO;
import com.moving.DTO.OnscreenDTO;
import com.moving.DTO.PriceDTO;
import com.moving.DTO.TicketDTO;
import com.moving.DTO.TimeDTO;
import com.moving.main.Getters;
import com.moving.main.Main;

/**
 * 예매와 관련된 변수값을 얻는 클래스
 * @author 해나
 *
 */
public class CinemaGetters extends Getters {
	
	/**
	 * 지역과 극장 종류를 얻는 메소드
	 * @param localSeq 지역 식별번호
	 * @param companySeq 회사 식별번호
	 * @return String 지역+회사
	 */
	public String getCinema(String localSeq, String companySeq) {
		
		String cinema = "";
		
		for(LocalDTO l : Main.localList) {
			if(l.getLocalSeq().trim().equals(localSeq)) {
				cinema = l.getLocal() + " ";
				break;
			}
		}
		
		for(CompanyDTO c : Main.companyList) {
			if(c.getCompanySeq().equals(companySeq)) {
				cinema += c.getCompany();
				break;
			}		
		}
		
		return cinema;
	}
	
	
	/**
	 * 영화 시간을 얻는 메소드
	 * @param timeSeq 시간 식별자
	 * @return String 시간 00:00 형태
	 */
	public String getTime(String timeSeq) {
		
		String time = "";
		for(TimeDTO t : Main.timeList) {
			if(t.getTimeSeq().equals(timeSeq)) {
				time = t.getTime();
			}
		}
		return time;
	}
	
	
	/**
	 * 좌석의 번호를 구하는 메소드
	 * @param seatName 좌석의 이름
	 * @return int 좌석 번호
	 */
	public int getSeatNum(String seatName) {
		
		char alphabet = seatName.charAt(0);
		int num = Integer.parseInt(seatName.substring(1));
		
		int SeatNum = (alphabet-65) * 15 - 1 + num;
		return SeatNum;

	}
	
	
	/**
	 * 날짜를 받아 월, 일을 반환
	 * @param date 날짜 0000-00-00
	 * @return 0월0일
	 */
	public static String getKoreanDate(String date) {
		String[] list = date.split("-");
		String s = list[1] + "월 " + list[2] + "일";
		return  s;
	}
	
	
	/**
	 * 좌석번호를 좌석 이름으로 바꿔주는 메소드
	 * @param seatNum 좌석 번호
	 * @return String 좌석 이름
	 */
	public String getSeatName(String seatNum) {
		int num = Integer.parseInt(seatNum) % 15 + 1;
		int alphabet = (Integer.parseInt(seatNum) - num + 1)/15 + 65;
		
		String seatName = (char)(alphabet) + "" + num; 
		return seatName;
	}
	
	
	/**
	 * 예매율을 구하는 메소드
	 * @param movieSeq 영화 식별 번호
	 * @return double 예매율(퍼센트)
	 */
	public double countVeiwers(String movieSeq) {
		
		ArrayList<String> onscreenSeqList = new ArrayList<String>();
		double count = 0;
		
		for(OnscreenDTO o : Main.onscreenList) {
			if(o.getMovieSeq().equals(movieSeq)) {
				onscreenSeqList.add(o.getOnscreenSeq());
			}
		}
		
		for(String s : onscreenSeqList) {
			for(TicketDTO t : Main.ticketList) {
		
				if(t.getOnscreenSeq().equals(s)) {
					count++;
				}
			}
		}
		
		double percent = count / Main.ticketList.size() * 100;
		return percent;
	}
	
	/**
	 * 가격을 얻는 메소드
	 * @param priceSeq 좌석 타입 번호
	 * @return 좌석 가격
	 */
	public int getPrice(String priceSeq) {
	
		int price = 0;
		
		for(PriceDTO p : Main.priceList) {
			if(p.getPriceSeq().equals(priceSeq)) {
				price = p.getPrice();
			}
		}
		
		return price;
	}

	/**
	 * 가격을 얻는 메소드
	 * @param priceSeq 좌석 타입 번호
	 * @return 좌석 가격
	 */
	public String getPriceType(String priceSeq) {
		
		String type = "";
		
		for(PriceDTO p : Main.priceList) {
			if(p.getPriceSeq().equals(priceSeq)) {
				type = p.getPriceType();
			}
		}
		
		return type;
	}
	

}

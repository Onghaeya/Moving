package com.moving.booking;

import java.util.Scanner;

import com.moving.DTO.*;
import com.moving.main.Main;
import com.moving.search.SearchUI;

/**
 * 영화관 선택
 * @author 해나
 *
 */
public class ChooseCinema {
	
	private String localSeq;
	private String companySeq;
	
	/**
	 * ChooseCinema 클래스의 식별자
	 */
	public ChooseCinema() {
		localSeq = ""	;
		companySeq = "";
	}
	
	/**
	 * 예매할 영화의 지역을 선택하는 메소드
	 */
	public void chooseTown() {
		
		boolean loop = true;		
		while(loop) {
			
			Scanner scan = new Scanner(System.in);
			System.out.println();
			for(int i=0; i<Main.localList.size(); i++) {
				System.out.printf("%3s. %s\t   "
												, Main.localList.get(i).getLocalSeq()
												, Main.localList.get(i).getLocal());
				if((i + 1) % 3 == 0) {
					System.out.println();
				}
			}
		
			System.out.println();
			System.out.println();
			System.out.print("지역 번호 > ");
			localSeq =  scan.nextLine();
			
			
			if(localSeq.equals("0")) {
				loop = false;
			} else if(Integer.parseInt(localSeq) <= Main.localList.size()) {
				
				BookingService.choice.setLocalSeq(localSeq);
				System.out.println();
				chooseCompany();
				return;
			
			} else {
				SearchUI.inputError();
			}
		}
	}
	
	/**
	 * 예매할 영화관을 선택하는 메소드
	 */
	public void chooseCompany() {
		
		boolean loop = true;
		Scanner scan = new Scanner(System.in);
		
		while(loop) {
			for(CompanyDTO c : Main.companyList) {
			System.out.printf("%s. %s\n", c.getCompanySeq(), c.getCompany());
			}
		
			System.out.println();
			System.out.print("극장 번호 > ");
			companySeq =  scan.nextLine();
			System.out.println();
			
			if(localSeq.equals("0")) {
				loop = false;
			} else if(Integer.parseInt(companySeq) <= Main.companyList.size()) {
				
				BookingService.choice.setCompanySeq(companySeq);
				return;
			
			} else {
				SearchUI.inputError();
			}
		}
	}
	
}

package com.moving.booking;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.moving.DTO.MovieDTO;
import com.moving.DTO.OnscreenDTO;
import com.moving.main.Main;
import com.moving.search.SearchUI;
/**
 * 예매 영화 선택
 * @author 해나
 *
 */
public class ChooseMovie extends CinemaGetters {
	
	Scanner scan = new Scanner(System.in);
	
	/**
	 * 영화를 선택하는 메소드
	 */
	public void chooseMovie() {
		
		boolean loop = true;
		while(loop) {
			
			ArrayList<String> seqList = new ArrayList<String>();
			String movieSeq = "";
			for(MovieDTO m : Main.movieList)	{
				if(m.getState().equals("1")) {
					System.out.printf("%4s. %s\n", m.getSeq(), m.getTitle());
					seqList.add(m.getSeq());
				}
			}
			
			boolean loop2 = true;
			while(loop2) {
				
				System.out.println();
				System.out.print("예매할 영화 번호 > ");
				movieSeq = scan.nextLine();
				System.out.println();
				System.out.println();
				
				if(movieSeq.equals("0")) {
					return;
				} else if(seqList.contains(movieSeq)) {
					BookingService.choice.setMovieSeq(movieSeq);
					chooseDate();
					return;
				} else {
					SearchUI.inputError();
				}
			}
		}
	}
	
	/**
	 * 날짜를 선택하는 메소드
	 */
	public void chooseDate() {
		
		ArrayList<String> dateList = new ArrayList<String>();
		String date = "";
		
		System.out.printf("%s < %s >의 상영 날짜\n"
										, getCinema(BookingService.choice.getLocalSeq()
															, BookingService.choice.getCompanySeq())
										, getTitle(BookingService.choice.getMovieSeq()));
		
		for(OnscreenDTO o : Main.onscreenList) {
			if(o.getLocalSeq().equals(BookingService.choice.getLocalSeq())
					&& o.getCompanySeq().equals(BookingService.choice.getCompanySeq())
					&& o.getMovieSeq().equals(BookingService.choice.getMovieSeq())) {
				
				if(!dateList.contains(o.getDay())) {	
					dateList.add(o.getDay());
				}
			}
		}
		
	
		for(int i=0; i<dateList.size(); i++) {
			String[] splitDate = dateList.get(i).split("-");
			System.out.printf("%d. %s월 %s일\n", i + 1, splitDate[1], splitDate[2]);
		}
		
		System.out.println();
		System.out.print("원하는 날짜의 번호를 입력하세요 > ");
		int dateNum = scan.nextInt();
		scan.nextLine();
		date = dateList.get(dateNum - 1);
		
		if(dateNum == 0) {
			return;
		} else if(dateNum <= dateList.size()) {
			BookingService.choice.setDay(date);
			chooseTime();
		} else {
			SearchUI.inputError();
		}
		
	
	}

	/**
	 * 예매 시간 선택 메소드
	 */
	public void chooseTime() {
		
		int timeSel = 0;;
		int num = 1;
		
		ArrayList<String> onscreenSeqList = new ArrayList<String>();
		ArrayList<String> timeSeqList = new ArrayList<String>();
		
		System.out.println();
		System.out.printf("%s  < %s >의 상영 시간\n"
										, getCinema(BookingService.choice.getLocalSeq()
															, BookingService.choice.getCompanySeq())
										, getTitle(BookingService.choice.getMovieSeq()));
		
		for(OnscreenDTO o : Main.onscreenList) { 
			 
			
			if(o.getLocalSeq().equals(BookingService.choice.getLocalSeq())
					&& o.getCompanySeq().equals(BookingService.choice.getCompanySeq())
					&& o.getMovieSeq().equals(BookingService.choice.getMovieSeq())
					&& o.getDay().equals(BookingService.choice.getDay())) {
				
				System.out.printf("%2s. %s\n", num, getTime(o.getTimeSeq()));
				timeSeqList.add(num - 1, o.getTimeSeq());
				onscreenSeqList.add(num-1, o.getOnscreenSeq());
				num++;
			}
		
		}
		
		System.out.println();
		System.out.print("원하는 시간의 번호를 입력하세요 > ");
		timeSel = scan.nextInt();
		System.out.println();
		scan.nextLine();
		
		if(timeSel == 0) {
			return;
		} else if(timeSel <= timeSeqList.size()) {
			BookingService.choice.setTimeSeq(timeSeqList.get(timeSel - 1));
			BookingService.choice.setOnscreenSeq(onscreenSeqList.get(timeSel - 1));
			
			ChooseSeat seat = new ChooseSeat();
			seat.chooseSeat();
		} else {
			SearchUI.inputError();
		}
		
	}
}



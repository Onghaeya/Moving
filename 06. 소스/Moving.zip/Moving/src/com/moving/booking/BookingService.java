package com.moving.booking;

import java.util.Scanner;

import com.moving.DTO.OnscreenDTO;
import com.moving.main.UI;
import com.moving.search.SearchUI;

/**
 * 예매 페이지 메뉴 클래스
 * @author user
 *
 */
public class BookingService {
	
	public static OnscreenDTO choice;
	
	static {
		choice = new OnscreenDTO();
		choice.setEvent("0");
	}
	
	/**
	 * 예매 메뉴 메소드
	 */
	public void bookingMenu() {
		
		boolean loop = true;
		Scanner scan = new Scanner(System.in);
	
		while(loop) {
			UI.clear();	
			UI.title("영화 예매");
			BookingUI.getBookingMenu();
			System.out.println();
			
			System.out.println("원하는 예매를 입력하세요");
			System.out.print("입력 > ");
			String sel = scan.nextLine();
			
			if(sel.equals("1")) {
				ChooseCinema c = new ChooseCinema();
				c.chooseTown();
				
				ChooseMovie m = new ChooseMovie();
				m.chooseMovie();
				
			} else if(sel.equals("2")) {
				
				MovieBooking b = new MovieBooking();
				b.movieBooking();
				
				ChooseCinema c = new ChooseCinema();
				c.chooseTown();
				
				ChooseMovie m = new ChooseMovie();
				m.chooseDate();
				
			} else if(sel.equals("0")) {
				loop = false;
			} else {
				SearchUI.inputError();
			}
			
			
		}
	}
	
}

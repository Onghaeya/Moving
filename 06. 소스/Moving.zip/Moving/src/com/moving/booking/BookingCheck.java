package com.moving.booking;

import java.util.ArrayList;

import com.moving.DTO.OnscreenDTO;
import com.moving.DTO.TicketDTO;
import com.moving.main.Main;

/**
 * 예매 확인 클래스
 * @author 해나
 *
 */
public class BookingCheck extends CinemaGetters {

	/**
	 * 예매확인 메소드
	 */
	public void ticketCheck() {
		
		ArrayList<TicketDTO> ticketList = new ArrayList<TicketDTO>();
		
		for(TicketDTO t : Main.ticketList) {
			
			int count = 0;
			
			if(t.getMemberSeq().equals(Main.memberSeq)) {		
				for(int i=0; i<ticketList.size(); i++) {
					
					if(ticketList.get(i).getOnscreenSeq().equals(t.getOnscreenSeq())) {
						ticketList.get(i).setSeat(ticketList.get(i).getSeat() + ", " + t.getSeat());
						count++;
					}
					
				}
				
				if(count == 0) {
					TicketDTO temp = new TicketDTO();
					temp.setMemberSeq(Main.memberSeq);
					temp.setOnscreenSeq(t.getOnscreenSeq());
					temp.setSeat(t.getSeat());
					
					ticketList.add(temp);
				}
			}
		
		}
		

		for(int i=0; i<ticketList.size(); i++) {
			
			for(OnscreenDTO o : Main.onscreenList) {
				
				if(ticketList.get(i).getOnscreenSeq().equals(o.getOnscreenSeq())) {
					
					BookingUI.getTicket();
					System.out.println();
					
					System.out.println("< " + getTitle(o.getMovieSeq()) + " >");
					System.out.println();
					
					System.out.println("*장소");
					System.out.println(getCinema(o.getLocalSeq(), o.getCompanySeq()));
					System.out.println();
					
					System.out.println("*날짜");
					System.out.println(getKoreanDate(o.getDay()));
					System.out.println();
					//TODO 끝나는 시간 쓰기
					System.out.println("*상영시간");
					System.out.println(getTime(o.getTimeSeq()));
					System.out.println();
					
					String[] splitSeat = ticketList.get(i).getSeat().split(", ");
					System.out.println("*좌석");
					for(int j=0; j<splitSeat.length; j++) {
						System.out.print(getSeatName(splitSeat[j]) + "  ");	
					}
				
					System.out.println();		
					System.out.println();
					System.out.println("---------------------------");
					System.out.println();
					
				}
			}
		}
		
	}
	
}

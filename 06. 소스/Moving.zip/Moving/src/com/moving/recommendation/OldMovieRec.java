package com.moving.recommendation;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.moving.DTO.ActorDTO;
import com.moving.DTO.ActorFilmoDTO;
import com.moving.DTO.DirectorDTO;
import com.moving.DTO.DirectorFilmoDTO;
import com.moving.DTO.GenreDTO;
import com.moving.DTO.MovieDTO;
import com.moving.DTO.WishlistDTO;
import com.moving.info.MovieInfo;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.SearchUI;
/**
 * 
 * @author 허영
 * 상영 종료 영화 추천 페이지에서 쓰이는 메소드들을 모아놓은 클래스
 *
 */
public class OldMovieRec {

	private static Scanner scan = new Scanner(System.in);
	private static ArrayList<DirectorDTO> directorList;
	private static ArrayList<DirectorFilmoDTO> directorFilmoList;
	private static ArrayList<MovieDTO> movieList;
	private static ArrayList<ActorFilmoDTO> actorFilmoList;
	private static ArrayList<ActorDTO> actorList;
	private static ArrayList<GenreDTO> genreList;
	private static ArrayList<WishlistDTO> wishlistList;
	
	static  {
		
		OldMovieRec.directorList = Main.directorList;
		OldMovieRec.directorFilmoList = Main.directorFilmoList;
		OldMovieRec.movieList = Main.movieList;
		OldMovieRec.actorList = Main.actorList;
		OldMovieRec.actorFilmoList = Main.actorFilmoList;
		OldMovieRec.genreList = Main.genreList;
		OldMovieRec.wishlistList = Main.wishlistList;
	}
	
	
	/**
	 * 사용자가 입력한 감독의 영화를 찾아주는 메소드
	 */
	public static void directorBaseRec() {//해당 감독이 만든 영화를 Filmo에서 찾아서 검색DB에 연결
		
		System.out.println("추천 받고 싶은 감독을 검색해 주세요.");
		System.out.print("감독 이름: ");
		String dirName = scan.nextLine();
		
		ArrayList<String> list = new ArrayList();//검색된 감독이 없다면 size()가 0이 될것
		
		for(DirectorDTO director : directorList) {
			//System.out.println(director.getName());
			if(dirName.equals(director.getName())) {//검색한 감독이 DB에 존재하는지 확인
				String dirSeq = director.getSeq();//검색된 감독의 번호를 저장
				list.add(dirName);
				for(DirectorFilmoDTO directorFilmo : directorFilmoList) {
					if(directorFilmo.getDirectorSeq().equals(dirSeq)) {//filmo에서 해당 번호의 감독찾기
						
						for(MovieDTO movie : movieList) {
							if(movie.getSeq().equals(directorFilmo.getMovieSeq())) {//해당 번호를 가진 영화를 movie.dat에서 찾기
								System.out.println(movie.getTitle());
							}
						}
					}
				}
				
			} 
		} 
		
		if (list.size() == 0) {
			System.out.println("검색 내용이 없습니다.");
		}
		
		
		
	}


/**
 * 사용자가 입력한 배우의 작품을 찾아주는 메소드
 */
	public static void actorBaseRec() {
		
		System.out.println("추천 받고 싶은 배우을 검색해 주세요.");
		System.out.print("배우 이름: ");
		String acName = scan.nextLine();
		
		ArrayList<String> list = new ArrayList<String>();//검색된 배우가 없다면 size()가 0이 될것
		
		for(ActorDTO actor : actorList) {
			if(acName.equals(actor.getName())) {//검색한 배우가 DB에 존재하는지 확인
				String acSeq = actor.getSeq();//검색된 배우의 번호를 저장
				for(ActorFilmoDTO actorFilmo : actorFilmoList) {
					if(actorFilmo.getActorSeq().equals(acSeq)) {//filmo에서 해당 번호의 배우찾기
						
						for(MovieDTO movie : movieList) {
							if(movie.getSeq().equals(actorFilmo.getMovieSeq())) {//해당 번호를 가진 영화를 movie.dat에서 찾기
								System.out.println(movie.getTitle());
							}
						}
					}
				}
				
			} 
		}
		if (list.size() == 0) {
			System.out.println("검색 내용이 없습니다.");
		}
		
	}

/**
 * 사용자가 입력한 년도의 별점 4이상의 영화를 찾아주는 메소드
 */

	public static void yearBaseRec() {
		System.out.println("추천 받고 싶은 년도 검색해 주세요.");
		System.out.print("개봉 년도: ");
		String year = scan.nextLine();
		
		for(MovieDTO movie : movieList) {
			if(movie.getStartDay().contains(year)) {//개봉일이 해당 년도를 포함하고 있다면
				if(movie.getReviewerNum() != 0){
					if (movie.getTotalScore()/movie.getReviewerNum() >= 4) {//별점이 4점 이상일때
						System.out.println(movie.getTitle());
						//System.out.println("영화);
					}
				}
			} 
			
		}
		
		UI.enterPause();
		
	}


/**
 * 사용자가 입력한 장르의 4점이상 영화를 찾아주는 메소드
 */
	public static void genreBaseRec() {
		System.out.println("추천 받고 싶은 장르의 입력해주세요.");
		System.out.print("장르: ");
		String input = scan.nextLine();
		
		for(GenreDTO genre : genreList) {
			if(genre.getGenre().equals(input)) {//해당 장르를 찾아서
				for(MovieDTO movie : movieList) {
					if (movie.getGenreSeq().equals(genre.getSeq())) {//해당영화의 장르번호가 입력된 장르의 번호일때
						if(movie.getReviewerNum() != 0){//리뷰어 수가 존재하고
							if (movie.getTotalScore()/movie.getReviewerNum() >= 4) {//별점이 4점 이상일때
								System.out.println(movie.getTitle());
								//System.out.println("영화);
							}
						}
					}
				}
				
			} 
			
		}
		UI.enterPause();
	}


/**
 * 사용자의 위시리스트에 저장된 영화를 만든 감독의 다른 작품을 추천해주는 메소드
 */
	public static void wishlistBaseRec() {
		System.out.println("위시리스트에 저장된 영화를 바탕으로 추천됩니다.");
		
		ArrayList<String> list = new ArrayList<String>();//해당 회원 번호의 위시리스트가 발견될때마다 담을 배열
		
		for(WishlistDTO wishlist : wishlistList) {
			if(wishlist.getMemberSeq().equals(Main.memberSeq)){//해당 회원번호의 위시리스트가 찾아지면, 영화번호를 얻어내
				list.add(wishlist.getMovieSeq());
				for(DirectorFilmoDTO directorFilmo : directorFilmoList) {
					if(wishlist.getMovieSeq().equals(directorFilmo.getMovieSeq())) {//directorFilmoList에서 wishlist영화 번호와 같은 영화를 찾으면
						String dirSeq = directorFilmo.getDirectorSeq();//해당 영화를 만든 감독 번호를 찾아서
						for(DirectorFilmoDTO directorFilmo2 : directorFilmoList) {//감독 필모에서
							if(directorFilmo2.getDirectorSeq().equals(dirSeq)) {//해당 감독이 만든 영화가 찾아지면
								for(MovieDTO movie : movieList) {
									if(movie.getSeq().equals(directorFilmo2.getMovieSeq())) {//그 영화를 movie.dat에서 찾아 영화 정보 출력.
										System.out.print("[영화번호]"+movie.getSeq()+": ");
										System.out.println(movie.getTitle());
									}
								}
							}
						}
						
					}	
				}	
				
			} 
		}

		if(list.size() == 0) {
			System.out.println("위시리스트에 저장된 영화가 없습니다.");
		}
		
		System.out.print("자세히 볼 영화 번호 입력 > ");
		String sel = scan.next();
		if(sel.equals("0")) {
			return;
		} else if(list.contains(sel)) {
			MovieInfo m = new MovieInfo();
			m.info(sel);
		} else {
			SearchUI.inputError();
		}
		
	}
	
}



























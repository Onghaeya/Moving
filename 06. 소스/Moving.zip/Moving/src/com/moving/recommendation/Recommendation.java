package com.moving.recommendation;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.xml.bind.helpers.DefaultValidationEventHandler;

import com.moving.DTO.ActorDTO;
import com.moving.DTO.ActorFilmoDTO;
import com.moving.DTO.DirectorDTO;
import com.moving.DTO.DirectorFilmoDTO;
import com.moving.DTO.GenreDTO;
import com.moving.DTO.GradeDTO;
import com.moving.DTO.MovieDTO;
import com.moving.DTO.WishlistDTO;
import com.moving.info.MovieInfo;
import com.moving.main.Getters;
import com.moving.main.Main;
import com.moving.main.RecommendUI;
import com.moving.main.UI;
/**
 * 
 * @author 허영
 * 영화 추천 페이의 첫 페이지의 기능 메소드들로 구성된 클래스. 
 * 생성자 매개인자로 필요한 리스트들을 넘겨 받고 UI 구성.
 *
 */
public class Recommendation {
	
	private ArrayList<ActorDTO> actorList;
	private ArrayList<ActorFilmoDTO> actorFilmoList;
	private ArrayList<DirectorDTO> directorList;
	private ArrayList<DirectorFilmoDTO> directorFilmoList;
	private ArrayList<GenreDTO> genreList;
	private ArrayList<MovieDTO> movieList;
	private ArrayList<WishlistDTO> wishlistList;
	private ArrayList<GradeDTO> gradeList;
	
	private Scanner scan;
	private RecommendUI ui;
	private Random rnd;
	
	
	public Recommendation() {
		
		this.actorList = Main.actorList;
		this.actorFilmoList = Main.actorFilmoList;
		this.directorList = Main.directorList;
		this.directorFilmoList = Main.directorFilmoList;
		this.genreList = Main.genreList;
		this.movieList = Main.movieList;
		this.wishlistList = Main.wishlistList;
		this.gradeList = Main.gradeList;
		
		this.scan = new Scanner(System.in);
		this.ui = new RecommendUI();
		this.rnd = new Random();
		
	}//생성자
	
	
	/**
	 * 영화 추천 페이지의 첫화면을 부르는 메소드.
	 * 임의로 상영 영화를 하나 보여주고, 그 아래에 메뉴를 보여준다.
	 */
	public void start() {
		
		boolean loop = true;
		
		while (loop) {
			UI.clear();
			UI.title("상영 영화 추천");//영화 추전 첫페이지 메뉴
			ArrayList<MovieDTO> playingMovie = new ArrayList<MovieDTO>();//상영 영화를 담을 ArrayList
			for(MovieDTO movie: movieList) {
				if(movie.getState().equals("1")) {//상영 상태(1)이 영화만 playingMoive에 추가
					playingMovie.add(movie);
				}
			}
			
			MovieDTO selected = playingMovie.get(rnd.nextInt(playingMovie.size()+1));//playingMovie의 사이즈내에서 임의로 선택된 방에 있는 MovieDTO객체 반환
			System.out.println("º 영화제목: " + selected.getTitle());
			System.out.println("º 장르: " + getGenreName(selected.getGenreSeq()));
			System.out.println("º 관랍 등급: " + getGrade(selected.getGradeSeq()));
			System.out.println("º 별점: " + Getters.getStar(selected.getTotalScore(), selected.getReviewerNum()));
			System.out.println("º 줄거리: ");
			System.out.println("  " + Getters.devideLine(selected.getSynopsis()));
			
			
			
			ui.recommendStart2();//선택 화면 띄우기
			
			System.out.print("입력 > ");
			String sel = scan.nextLine();
			if (sel.equals("1")) {
				movieinfo(selected.getSeq());
			} else if (sel.equals("2")) {
				playingMovieList();
			} else if (sel.equals("3")) {
				oldMovieRec();
			} else {
				loop = false;
			}
		}
		
		System.out.println("상위 메뉴로 이동합니다.");
	}
	
	


/**
 * 상영 종료 영화 추천받을때, 추천 기준을 정하는 메소드
 */
	private void oldMovieRec() {
		
		boolean loop = true;
		while(loop) {
			ui.oldMovie0();
			
			String sel = scan.nextLine();
			if(sel.equals("1")) {//감독기준 추천받기
				OldMovieRec.directorBaseRec();
				System.out.println();

			} else if (sel.equals("2")) {
				OldMovieRec.actorBaseRec();
				System.out.println();
				
			} else if (sel.equals("3")) {
				OldMovieRec.yearBaseRec();
				System.out.println();
				
			} else if(sel.equals("4")){
				OldMovieRec.genreBaseRec();
				System.out.println();
			} else if(sel.equals("5")) {
				OldMovieRec.wishlistBaseRec();
				System.out.println();
			} else {
				loop= false;
			}
				
			
			
		}
		
		System.out.println("상위 메뉴로 이동합니다.");

	}


/**
 * 현재 상영 중인 영화를 보여주는 메소드
 */
	private void playingMovieList() {
		boolean loop = true;
		do{
			System.out.println("\t영화명\t\t\t장르\t관람등급\t\t별점");
			int num = 1;
			for(MovieDTO movie : movieList) {
				if(movie.getState().equals("1")){
					if (movie.getTotalScore()==0) {
						System.out.println(String.format("%2d. %-20.16s\t%-5s\t%-6s\t-",
								num, movie.getTitle(),
								getGenreName(movie.getGenreSeq()),
								getGrade(movie.getGradeSeq())));
					} else {
						System.out.println(String.format("%2d. %-20.16s\t%-5s\t%-6s\t"+Getters.getStar(movie.getReviewerNum(), movie.getTotalScore()),
													num, movie.getTitle(),
													getGenreName(movie.getGenreSeq()),
													getGrade(movie.getGradeSeq())
													));
					}
					num++;
				}
			}
			UI.line();
			System.out.print("뒤로 가기: 0");
			 if(scan.nextLine().equals("0")) {loop = false;}
			
		} while(loop);
	}

	/**
	 * 영화 번호를 받아서 해당 영화 정보를 출력하는 메소드
	 * @param movieSeq
	 */
	private void movieinfo(String movieSeq) {//영화 번호 넘겨옴
		boolean loop = true;
		do {
			for(MovieDTO movie : movieList) {
				if (movie.getSeq().equals(movieSeq)) {
					MovieInfo.info(movieSeq);
					loop = false;
					break;
				}
			}
			//상위 메뉴로 가기
//			System.out.println("------------------------------------------");
//			System.out.println("영화 상세 정보 여기에");
//			System.out.print("뒤로 가기: 0");
//			 if(scan.nextLine().equals("0")) {loop = false;}
//			
		} while(loop);
	}
/**
 * 장르 번호를 인자로 받아, 장르 이름을 반환하는 메소드
 * @param genreSeq
 * @return
 */
	public String getGenreName(String genreSeq) {//장르 넘버가 String으로 넘어옴
		
		String temp= ""; 
		for( GenreDTO genre : genreList) {
			if(genre.getSeq().equals(genreSeq)) {
				temp = genre.getGenre();//번호가 일치하는 경우의 장르를 temp에 저장
			}
		}
		return temp;
	}
	/**
	 * 관람등급 번호를 받아 관랍등급을 반환하는 메소드
	 * @param gradeSeq
	 * @return
	 */
	private String getGrade(String gradeSeq) {
		String temp= ""; 
		for( GradeDTO grade : gradeList) {
			if(grade.getSeq().equals(gradeSeq)) {
				temp = grade.getGrade();//번호가 일치하는 경우의 장르를 temp에 저장
			}
		}
		return temp;
	}
	
}

package com.moving.predict;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.ActorDTO;
import com.moving.DTO.ActorFilmoDTO;
import com.moving.DTO.DirectorFilmoDTO;
import com.moving.DTO.MovieDTO;
import com.moving.info.AddWishlist;
import com.moving.info.InfoUI;
import com.moving.main.FileUtil;
import com.moving.main.Getters;
import com.moving.main.Login;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.SearchUI;
/**
 * 예측 상세 보기
 * @author 해나
 *
 */
public class PredicDetail extends PredicMethods {
	/**
	 * 예측 상세 보기 
	 * @param movieSeq 영화 식별 번호
	 */
	public void detail(String movieSeq) {
		
		UI.clear();
		
		//메뉴넣기
		boolean loop = true;
		
		while (loop) {
			
			UI.clear();
			UI.title("예측 상세 보기");
			MovieDTO temp = new MovieDTO();
		
			for(MovieDTO m : Main.movieList) {
				if(m.getSeq().equals(movieSeq)) {
					temp = m;
					break;
				}
			}
			
			ArrayList<String> actorsAList = getAActors(movieSeq);
			ArrayList<String> actorsSeqList = getActorSeq(movieSeq);
			String dirSeq = "";
			InfoUI.getMovieMenu(temp.getSeq(), temp.getState());
			UI.line();
			
			for(DirectorFilmoDTO d : Main.directorFilmoList) {
				if(d.getMovieSeq().equals(temp.getSeq())) {
					dirSeq = d.getDirectorSeq();
				}
			}
			
			//제목
			System.out.printf("\n<< %s >>\n\n", temp.getTitle());
			//영화감독
			System.out.printf("★ 감독 흥행 성적 : %s (%s)\n"
											, getDirector(temp.getSeq())
											, changeToA(getDirScore(dirSeq)));
			System.out.println();
			
			//영화배우
			System.out.println("★ 배우 흥행 성적 : ");
			//주연
			for(int i=0; i<actorsAList.size(); i++) {
				String actorSeq = actorsSeqList.get(i);
				System.out.printf("   %s (%s)\n"
												, getActorName(actorSeq)
												, changeToA(getActorScore(actorSeq)));
			}	
			
			System.out.println();
			
			//국적
			System.out.printf("★ 국적 : %s (%s)\n"
											, getCountry(temp.getCountrySeq())
											, changeToA(getCountryScore(temp.getCountrySeq())));
			System.out.println();	
			
			//장르 구하기
			System.out.printf("★ 장르 : %s (%s)\n"
											, getGenre(temp.getGenreSeq())
											, changeToA(getGenreScore(temp.getGenreSeq())));
			System.out.println();
			
			//별점
			System.out.println("★ 별점 : " 
												+ getStar(temp.getReviewerNum(), temp.getTotalScore()));
			System.out.println();

			//개봉일 구하기
			System.out.println("★ 개봉일 : " 
												+ getYear(temp.getStartDay()) + "년 " + getKoreanDate(temp.getStartDay()));
			System.out.println();
			
			//줄거리
			System.out.println("★ 줄거리 : ");
			System.out.println("   " + devideLine(temp.getSynopsis()));
			System.out.println();
			
			System.out.println();
			
			boolean loop2 = true; 		
			while(loop2) {
				
				Scanner scan = new Scanner(System.in);
				System.out.print("입력 > ");
				String sel = scan.nextLine();
		
				if(sel.equals("1")) {
					
					AddWishlist add = new AddWishlist();
					if(Main.login.equals("1")) {
						
						if(!Getters.isInWishlist(movieSeq)) {	
							add.addWishlist(movieSeq);
						} else {
							add.deleteWishlist(movieSeq);
						}
						
						
						FileUtil.memberSave();
						SearchUI.pause();
						loop2 = false;
						
					} else {
						System.out.println("로그인하세요");
						Login a = new Login();
						a.start();
						loop2 = false;
					}
					
				} else if(sel.equals("2")) {
					
					System.out.print("별점 (1~5 정수 입력) : ");
					int score = scan.nextInt();
					scan.nextLine();
					System.out.printf("%d점이 추가되었습니다 :D\n\n", score);
					
					temp.setTotalScore(temp.getTotalScore() + score);
					temp.setReviewerNum(temp.getReviewerNum() + 1);
					
					UI.enterPause();
					FileUtil.movieSave();
					
					loop2 = false;
					
				} else if(sel.equals("3")) {
					
					try {
						
						if(temp.getTrailer().startsWith("http")) {
							System.out.println("\n예고편을 실행합니다.");
							UI.enterPause();
							Process iexplore	= new ProcessBuilder("C:\\Program Files\\Internet Explorer\\iexplore.exe", temp.getTrailer()).start();
						} else {
							System.out.println("실행할 수 없습니다.\n");
						}
						
					} catch (Exception e) {
						System.out.println(e.toString());
					}
				} else if(sel.equals("0")) {
					loop2= false;
					loop = false;
				}
			}
 					
		}
	}
	
	/**
	 * 해당 영화 출연한 배우의 번호 얻는 메소드
	 * @param movieSeq 영화 번호
	 * @return ArrayList<String> 출연진의 영화 번호
	 */
	public ArrayList<String> getActorSeq(String movieSeq) {
		
		ArrayList<String> actorSeqList = new ArrayList<String>();
		
		for(ActorFilmoDTO m : Main.actorFilmoList) {
			if(m.getMovieSeq().equals(movieSeq) 
					&& m.getMovieRole().equals("A")) {
				actorSeqList.add(m.getActorSeq());
			}
		}
		return actorSeqList;
	}
	
	public String getActorName(String actorSeq) {
		String name = "";
		for(ActorDTO a : Main.actorList) {
			if(a.getSeq().equals(actorSeq)) {
				name = a.getName();
			}
		}
		return name;
	}
	
	
}

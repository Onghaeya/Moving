package com.moving.predict;

import com.moving.DTO.MovieDTO;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 흥행 예측 첫 페이지
 * @author 해나
 *
 */
public class PredicList extends PredicMethods {
	
	/**
	 * 흥행 예측 영화 목록
	 */
	public void predictList() {
		
		boolean loop = true;
		while(loop) {
			UI.clear();
			UI.title("영화 흥행 예측");
			System.out.println("흥행예측이란?  해당 영화 감독 및 배우의 흥행점수, 영화가 제작된 나라, \n별점 등으로 영화의 흥행 가능성을 5단계로 예측합니다.");
			UI.line();
			System.out.println("[번호]\t[제목]     \t[예측]  \t[개봉일] \t\t[장르]  [감독]");
			UI.line();
			for(MovieDTO m : Main.movieList) {
				if(isLater(m.getStartDay())) {
					System.out.printf("%5s\t%-10.7s    \t%s\t%10s\t%s  \t%s\n"
													, m.getSeq()
													, m.getTitle()
													, getTotalScore(m.getSeq())
													, m.getStartDay()
													, getGenre(m.getGenreSeq())
													, getDirector(m.getSeq()));		
					System.out.println();
					
				}
			}
			System.out.print("분석 세부사항을 조회할 영화 번호를 입력하세요 > ");
			String movieSeq = scan.nextLine();
			
			if(movieSeq.equals("0")) {
				loop = false;				
			} else {
				PredicDetail p = new PredicDetail();
				p.detail(movieSeq);
			}
			
		}
	}
}

package com.moving.predict;

import java.util.Calendar;

import com.moving.DTO.ActorFilmoDTO;
import com.moving.DTO.DirectorFilmoDTO;
import com.moving.DTO.MovieDTO;
import com.moving.booking.CinemaGetters;
import com.moving.main.Main;

/**
 * 예측을 위한 계산 메소드 모음
 * @author 해나
 *
 */
public class PredicMethods extends CinemaGetters {
		/**
		 * 감독의 흥행 점수를 계산하는 메소드
		 * @param directorSeq 감독 식별 번호
		 * @return int 감독의 점수
		 */
		public int getDirScore(String directorSeq) {
			int viewer = 0;
			int viewerCount = 0;
			int count = 0;
			int score = 0;
			for(DirectorFilmoDTO d : Main.directorFilmoList) {
				if(d.getDirectorSeq().equals(directorSeq)) {
					viewer = getViewer(d.getMovieSeq());
					viewerCount += viewer;
					
					if(!(viewer == 0)) {
						count++;
					}
				
				}
			
			}
			
			if(count == 0) {
				return 0;
			} else {
				score = viewerCount / count;
				
				if(score > 2000000)  return 5;
				else if(score > 1000000) return 4;
				else if(score > 600000) return 3;
				else if(score > 300000) return 2;
				else return 1;
			
			}
		}
		
		public int getViewer(String movieSeq) {
			
			int num = 0;
			
			for(MovieDTO m : Main.movieList) {
				if(m.getSeq().equals(movieSeq)) {
					num = m.getAudience();
				}
			}
			return num;
		}
		
		/**
		 * 배우의 흥행 점수를 계산하는 메소드
		 * @param actorSeq 배우의 식별 번호
		 * @return int 배우의 점수
		 */
		public int getActorScore(String actorSeq) {
			int viewer = 0;
			int viewerCount = 0;
			int count = 0;
			int score = 0;
			
			for(ActorFilmoDTO d : Main.actorFilmoList) {
				if(d.getActorSeq().equals(actorSeq)) {
					viewer = getViewer(d.getMovieSeq());
					viewerCount += viewer;
					
					if(!(viewer == 0)) {
						count++;
					}
				
				}
			
			}
			
			if(count == 0) {
				return 0;
			} else {
				score = viewerCount / count;
				
				if(score > 1000000)  return 5;
				else if(score > 800000) return 4;
				else if(score > 500000) return 3;
				else if(score > 100000) return 2;
				else return 1;
			}
		}
		
		/**
		 * 장르의 흥행 점수를 계산하는 메소드
		 * @param genreSeq 장르 식별 번호
		 * @return int 장르의 점수
		 */
		public int getGenreScore (String genreSeq) {
			
			int grade = 0;
			
			switch(Integer.parseInt(genreSeq)) {
				case 1 :
				case 15 : 
				case 16 :
				case 19 : 	grade = 5; 
							   	break;
				
				case 9:
				case 10 :
				case 13 :
				case 17 :	grade = 4;
								break;
								
				case 6 :
				case 7 :
				case 14 :
				case 18 :	grade = 3;
								break;
				
				case 2 :
				case 4 :
				case 5 :
				case 11 :	grade = 2;
								break;
				
				case 3 :
				case 8 :
				case 12 :
				case 20 :	grade = 1;
								break;
			}
			return grade;
		}
		
		/**
		 * 현재보다 나중에 나오는 영화인지 확인하는 메소드
		 * @param date 영화의 개봉 날짜
		 * @return 나중이면 true 아니면 false
		 */
		public boolean isLater(String date) {
			
			String[] temp = date.split("-");
			Calendar c = Calendar.getInstance();
			boolean answer = true;
			if(Integer.parseInt(temp[0]) > c.get(Calendar.YEAR)) {
				answer =  true;
			} else if(Integer.parseInt(temp[0]) < c.get(Calendar.YEAR)) {
				answer = false;
			} else if(Integer.parseInt(getRidOfZero(temp[1])) > c.get(Calendar.MONTH) + 1) {
				System.out.println(getRidOfZero(temp[1]));
				answer = true;
			} else if(Integer.parseInt(getRidOfZero(temp[1])) < c.get(Calendar.MONTH) + 1) {
				answer = false;
			} else if(Integer.parseInt(getRidOfZero(temp[2])) > c.get(Calendar.DATE)) {
				answer = true;
			} else if(Integer.parseInt(getRidOfZero(temp[2])) < c.get(Calendar.DATE)) {
				answer = false;
			} else {
				answer = true;
			}
			
			return answer;
		}
		
		/**
		 * 처음에 나오는 0을 제거하는 메소드
		 * @param num 숫자
		 * @return String 0을 제거한 숫자
		 */
		public String getRidOfZero(String num) {
			
			String realNum = "";
			if(num.startsWith("0")) {
				realNum = num.substring(1);
			} else {
				realNum = num;
			}
			
			return realNum;
		}
		
		/**
		 * 영화의 총 흥행점수를 계산하는 메소드
		 * @param movieSeq 영화 번호
		 * @return String 영화의 흥행 점수
		 */
		public String getTotalScore(String movieSeq) {
			
			MovieDTO temp = new MovieDTO();
			int actorTotalScore = 0;
			int directorTotalScore = 0;
			double genreAvrScore = 0;
			double actorAvrScore = 0;
			double dirAvrScore = 0;
			int count = 0;
			
			for(MovieDTO m : Main.movieList) {
				if(m.getSeq().equals(movieSeq)) {
					temp = m;
				}
			}
			
			//배우 점수
			for(ActorFilmoDTO a : Main.actorFilmoList) {
				if(a.getMovieSeq().equals(temp.getSeq())
						&& a.getMovieRole().equals("A")) {
					actorTotalScore = getActorScore(a.getActorSeq());
					count++;
				}
			}
			if(!(count == 0)) {
			actorAvrScore = actorTotalScore / count;
		} else {
			actorAvrScore = 3;
		}
		
		count = 0;
		//감독 점수
		for(DirectorFilmoDTO d : Main.directorFilmoList) {
			if(d.getMovieSeq().equals(temp.getSeq())) {
				directorTotalScore = getDirScore(d.getDirectorSeq());
				count ++;
			}
		}
		
		if(!(count == 0)) {
			dirAvrScore = directorTotalScore / count;
		} else {
			dirAvrScore = 3;
		}
		genreAvrScore = getGenreScore(temp.getGenreSeq());
		
		double totalScore = dirAvrScore * 0.55
										+ actorAvrScore * 0.1
										+ genreAvrScore * 0.2
										+ getCountryScore(temp.getCountrySeq()) * 0.1
										+ starScore(movieSeq) * 0.05;

		String StringScore = "";
		if(totalScore >= 4.5) {
			StringScore = ":D";
		} else if(totalScore >= 4) {
		    StringScore = ":)";
		} else if(totalScore >= 3) {
			StringScore = ":|";
		} else if(totalScore >= 2) {
			StringScore = ":/";
		} else {
			StringScore = ":(";
		}
		return StringScore;
	}
		
	/**
	 * 영화의 별점을 계산하는 메소드
	 * @param movieSeq 영화 번호
	 * @return int 영화의 별점 점수
	 */
	public int starScore(String movieSeq) {
	
		int starScore = 0;
		for(MovieDTO m : Main.movieList) {
			if(m.getSeq().equals(movieSeq)) {
				if(!(m.getReviewerNum() == 0)) {
					
					starScore = m.getTotalScore()/m.getReviewerNum();
					
				} else starScore = 3;
			}
		}
		return starScore;
	}
	
//	public int getCountryScore(String countrySeq) {
//		
//		int score = 0;
//		
//		switch(Integer.parseInt(countrySeq)) {
//		
//		case
//		case
//		case
//		case
//		
//		}
//	}
	
	/**
	 * 각 점수를 알파벳으로 바꿔주는 메소드
	 * @param score 점수
	 * @return String 알파벳
	 */
	public String changeToA(int score) {
		
		String Stringscore = "";
		if(score >= 4.5) {
			Stringscore = "A";
		} else if(score >= 4) {
		    Stringscore = "B";
		} else if(score >= 3) {
			Stringscore = "C";
		} else if(score >= 2) {
			Stringscore = "D";
		} else {
			Stringscore = "E";
		}
		return Stringscore;
	}
	
	/**
	 * 영화의 나라별 점수를 계산하는 메소드
	 * @param countrySeq 영화 식별 번호
	 * @return int 영화 점수
	 */
	public int getCountryScore(String countrySeq) {
		int countryScore = 0;
		
		switch(Integer.parseInt(countrySeq)) {
		case 25 : 
		case 64 : 
		case 137 : 
		case 157 : countryScore = 5;
						break;
		
		case 34 :
		case 109 : 
		case 141 :
		case 212 : countryScore = 4;
						break;
						
		case 21 : 
		case 29 : 
		case 165 : 
		case 177 : countryScore = 3;
						break;
		
		default : countryScore = 1;
						break;
		}
		
		return countryScore;
	}
		
}

	



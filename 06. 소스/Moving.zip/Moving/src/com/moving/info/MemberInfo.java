package com.moving.info;

import com.moving.main.FileUtil;
import com.moving.main.Join;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 인물 정보 출력 클래스
 * @author 박
 *
 */
public class MemberInfo extends UI {
	
	/**
	 * 인물 정보 출력 메소드
	 */
	public void info() {
		
		Join in = new Join();
		boolean loop = true;
		boolean loop2 = true;
		String sel = "";
		
		while (loop) {
			loop2 = true;
			
			UI.clear();
			UI.title("회원 정보");
			System.out.println("숫자. 해당 정보 수정  00.회원탈퇴  0.상위 메뉴로");
			UI.line();
			
			System.out.println("1.이름 수정");
			System.out.println("현재 이름 : "+Main.memberList.get(Integer.parseInt(Main.memberSeq)).getName());
			System.out.println();
			System.out.println("2.생일 수정");
			System.out.println("현재 생일 : "+Main.memberList.get(Integer.parseInt(Main.memberSeq)).getBirthday());
			System.out.println();
			System.out.println("3.메일주소 수정");
			System.out.println("현재 메일주소 : "+Main.memberList.get(Integer.parseInt(Main.memberSeq)).getEmail());
			System.out.println();
			System.out.println("4.전화번호 수정");
			System.out.println("현재 전화번호 : "+Main.memberList.get(Integer.parseInt(Main.memberSeq)).getTel());
			System.out.println();
			System.out.println("5.비밀번호 바꾸기");
			
			sel = UI.pause();
			
			if (sel.equals("1")) {
				System.out.println();
				sel = editPause();
				
				Main.memberList.get(Integer.parseInt(Main.memberSeq)).setName(sel);
				FileUtil.memberSave();
				System.out.println("수정 성공!");
				UI.enterPause();
			} else if (sel.equals("2")) {
				loop2 = false;
				while (!loop2) {
					System.out.println();
					System.out.println("생년월일을 입력해주세요");
					sel = namedPause("ex)19990101");
					loop2 = in.birthcheck(sel);
				}
				sel = sel.substring(0, 4) + "-"  +sel.substring(4, 6) + "-" + sel.substring(6, 8);
				
				Main.memberList.get(Integer.parseInt(Main.memberSeq)).setBirthday(sel);
				FileUtil.memberSave();
				System.out.println("수정 성공!");
				UI.enterPause();
			} else if (sel.equals("3")) {
				System.out.println();
				sel = editPause();
				
				Main.memberList.get(Integer.parseInt(Main.memberSeq)).setEmail(sel);
				FileUtil.memberSave();
				System.out.println("수정 성공!");
				UI.enterPause();
			} else if (sel.equals("4")) {
				loop2 = false;
				while (!loop2) {
					System.out.println();
					System.out.println("전화번호를 입력해주세요");
					sel = UI.namedPause("ex)01012345678");
					loop2 = in.telcheck(sel);
				}
				sel = sel.substring(0, 3) + "-" + sel.substring(3, 7) + "-" + sel.substring(7, 11);
				
				Main.memberList.get(Integer.parseInt(Main.memberSeq)).setTel(sel);
				FileUtil.memberSave();
				System.out.println("수정 성공!");
				UI.enterPause();
			} else if (sel.equals("5")) {
				String pw = "";
				String pwConfirm = "";
				while (loop2) {
					pw = UI.namedPause("변경하실 비밀번호를 입력하세요");
					pwConfirm = UI.namedPause("다시 한번 비밀번호를 입력하세요");
					if (pw.equals(pwConfirm)) {
						Main.memberList.get(Integer.parseInt(Main.memberSeq)).setPassword(pw);
						FileUtil.memberSave();
						System.out.println("비밀번호가 성공적으로 변경되었습니다");
						UI.enterPause();
						loop2 = false;
					} else {
						System.out.println("입력하신 비밀번호가 같지 않습니다");
					}
				}
			} else if (sel.equals("00")) {
				System.out.printf("정말로 이 회원을 삭제하시겠습니까? 원하시면 \"삭제\"를 입력하십시오\n");
				String reSel = editPause();
				if (reSel.equals("삭제")) {
					Main.memberList.remove(Main.memberSeq);
					FileUtil.memberSave();
					
					System.out.println("정상적으로 삭제되었습니다");
					enterPause();
					
					loop = false;
					Main.login = "-1";
				} else {}
			} else if (sel.equals("0")) {
				loop = false;
			}
		}
	}
}

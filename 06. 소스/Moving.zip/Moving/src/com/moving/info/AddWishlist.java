package com.moving.info;

import com.moving.DTO.WishlistDTO;
import com.moving.main.FileUtil;
import com.moving.main.Main;

/**
 * 위시리스트의 영화를 추가하거나 빼는 클래스
 * @author 해나
 *
 */
public class AddWishlist {
	
	/**
	 * 영화 위시리스트에 추가
	 * @param movieSeq 영화 식별 번호
	 */
	public void addWishlist(String movieSeq) {
		
		WishlistDTO temp2 = new WishlistDTO(); 
		temp2.setMemberSeq(Main.memberSeq);
		temp2.setMovieSeq(movieSeq);
		Main.wishlistList.add(temp2);
		System.out.println("위시리스트에 추가되었습니다.");
		FileUtil.memberSave();
		
	}
	
	
	/**
	 * 영화 위시리스트에서 삭제하기
	 * @param movieSeq 영화 식별번호
	 */
	public void deleteWishlist(String movieSeq) {
		
		for(int i=0; i<Main.wishlistList.size(); i++) {
			
			if(Main.wishlistList.get(i).getMemberSeq().equals(Main.memberSeq) 
					&& Main.wishlistList.get(i).getMovieSeq().equals(movieSeq)) {
				Main.wishlistList.remove(i);
				System.out.println("해당 영화가 위시리스트에서 삭제되었습니다.");
				FileUtil.memberSave();
				break;
			}
	
		}
	}
}

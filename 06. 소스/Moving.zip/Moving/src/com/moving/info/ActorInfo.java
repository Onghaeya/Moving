package com.moving.info;

import java.util.ArrayList;

import com.moving.DTO.ActorDTO;
import com.moving.booking.CinemaGetters;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.SearchUI;

/**
 * 배우 정보 출력 클래스
 * @author 해나
 *
 */
public class ActorInfo extends CinemaGetters {
	
	/**
	 * 배우정보 출력 메소드
	 * @param actorSeq 배우 식별번호
	 */
	public void info(String actorSeq) {
		
		boolean loop = true;
		
		ActorDTO temp = new ActorDTO();
		
		for(ActorDTO d : Main.actorList) {
			if(d.getSeq().equals(actorSeq)) {
				temp = d;
				break;
			}
		}
				
		while (loop) {

			ArrayList<String> workList = getWorks(actorSeq, 1);
		
			UI.title("배우 상세정보");

			SearchUI.getSubMenu();
			
			//이름
			System.out.printf("\n < %s >\n\n", temp.getName());
			
			//나이
			System.out.println("★ 생일 : " + getYear(temp.getBirth()) + "년 " + getKoreanDate(temp.getBirth()));
			System.out.println();
			
			//국적
			System.out.printf("★ 국적 : " + getCountry(temp.getCountrySeq()));
			System.out.println();
			System.out.println();
			
			//필모
			System.out.println("★ 필모그래피 : ");
			for(String s : workList) {
				System.out.println("   " + s);
			}
			System.out.println();
			
			System.out.println("★ 소개 : ");
			System.out.println(" " + devideLine(temp.getProfile()));
			System.out.println();

			System.out.print("입력 > ");
			
			String sel = scan.nextLine();
			
			if(sel.equals("0")) {
				loop = false;
			}
		}
	}

}

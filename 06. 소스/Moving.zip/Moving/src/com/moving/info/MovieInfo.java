package com.moving.info;

import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.MovieDTO;
import com.moving.booking.BookingService;
import com.moving.booking.ChooseCinema;
import com.moving.booking.ChooseMovie;
import com.moving.booking.CinemaGetters;
import com.moving.main.FileUtil;
import com.moving.main.Getters;
import com.moving.main.Login;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.SearchUI;


/**
 * 영화 세부정보 페이지
 * @author 해나
 *
 */
public class MovieInfo extends CinemaGetters {

	public static void info(String movieSeq) {
		
		boolean loop = true;
		
		while (loop) {
			MovieDTO temp = new MovieDTO();
		
			for(MovieDTO m : Main.movieList) {
				if(m.getSeq().equals(movieSeq)) {
					temp = m;
					break;
				}
			}
			
			ArrayList<String> actorsAList = getAActors(movieSeq);
			ArrayList<String> actorsBList = getBActors(movieSeq);
			UI.clear();
			UI.title("    영화 상세정보");
			InfoUI.getMovieMenu(temp.getSeq(), temp.getState());
			UI.line();
			
			//제목
			System.out.printf("\n<< %s >>\n\n", temp.getTitle());
			//영화감독
			System.out.println("★ 감독 : " + getDirector(movieSeq));
			System.out.println();
			
			//영화배우
			System.out.println("★ 배우 : ");
			//주연
			for(int i=0; i<actorsAList.size(); i++) {
				System.out.println("   " + actorsAList.get(i));
			}
			//조연
			for(int i=0; i<actorsBList.size(); i++) {
				System.out.println("   " + actorsBList.get(i));
			}
			
			System.out.println();
			
			//등급 구하기
			System.out.println("★ 등급 : " + getGrade(temp.getGradeSeq()));
			System.out.println();
			
			//장르 구하기
			System.out.println("★ 장르 : " + getGenre(temp.getGenreSeq()));
			System.out.println();
			
			//개봉일 구하기
			System.out.println("★ 개봉일 : " 
												+ getYear(temp.getStartDay()) + "년 " + getKoreanDate(temp.getStartDay()));
			System.out.println();
			
			//관객수
			System.out.printf("★ 관객수 : %,d명\n",getAudience(temp.getSeq()));
			System.out.println();
			
			
			//국적
			System.out.println("★ 국적 : " + getCountry(temp.getCountrySeq()));
			System.out.println();
			
			//줄거리
			System.out.println("★ 줄거리 : ");
			System.out.println("   " + devideLine(temp.getSynopsis()));
			System.out.println();
			
			//별점
			System.out.println("★ 별점 : " 
			                               + getStar(temp.getReviewerNum(), temp.getTotalScore()));
			System.out.println();
		
		
				Scanner scan = new Scanner(System.in);
				System.out.print("입력 > ");
				String sel = scan.nextLine();

				if(sel.equals("1")) {
					
					AddWishlist add = new AddWishlist();
					if(Main.login.equals("1")) {
						
						if(!Getters.isInWishlist(movieSeq)) {	
							add.addWishlist(movieSeq);
						} else {
							add.deleteWishlist(movieSeq);
						}
						
						FileUtil.memberSave();
						SearchUI.pause();
			
						
					} else {
						System.out.println("로그인하세요");
						Login a = new Login();
						a.start();
	
					}
					
				} else if(sel.equals("2")) {
					
					System.out.print("별점 (1~5 정수 입력) : ");
					int score = scan.nextInt();
					scan.nextLine();
					System.out.printf("%d점이 추가되었습니다 :D\n\n", score);
					
					temp.setTotalScore(temp.getTotalScore() + score);
					temp.setReviewerNum(temp.getReviewerNum() + 1);
					
					UI.enterPause();
					FileUtil.movieSave();
					
	
					
				} else if(sel.equals("3")) {
					
					try {
						
						if(temp.getTrailer().startsWith("http")) {
							System.out.println("\n예고편을 실행합니다.");
							UI.enterPause();
							Process iexplore	= new ProcessBuilder("C:\\Program Files\\Internet Explorer\\iexplore.exe", temp.getTrailer()).start();
						} else {
							System.out.println("실행할 수 없습니다.\n");
						}
						
					} catch (Exception e) {
						System.out.println(e.toString());
					}
					
				} else if(sel.equals("4")) {
					
					if(Main.login.equals("1")) {
						
						if(temp.getState().equals("1")) {
							BookingService.choice.setMovieSeq(movieSeq);
							
							ChooseCinema c = new ChooseCinema();
							c.chooseTown();
							
							ChooseMovie m = new ChooseMovie();
							m.chooseDate();
						} else {
							SearchUI.inputError();
						}				
						
					} else {
						System.out.println("로그인이 필요한 서비스입니다.");
						UI.enterPause();
						Login l = new Login();
						l.start();
						

					}
					
				} else if(sel.equals("0")) {
					return;
				} else {
					SearchUI.inputError();
					
				}
			
		}
		
	}


}

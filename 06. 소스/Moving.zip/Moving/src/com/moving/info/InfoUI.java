package com.moving.info;

import com.moving.main.Getters;

/**
 * 세부정보 UI
 * @author user
 *
 */
public class InfoUI {
	
	/**
	 * 영화 세부정보 페이지의 메뉴를 출력
	 * @param movieSeq 영화 번호
	 * @param state 상영 여부
	 */
	public static void getMovieMenu(String movieSeq, String state) {
		String s = "";
		
		if(Getters.isInWishlist(movieSeq)) {
			s = "빼기";
		} else {
			s = "추가";
		}
		
		System.out.printf("1. 위시리스트 %s     2. 별점주기     3. 예고편     ", s);
		
		if(state.equals("1")) System.out.print("4. 예매하기");

		System.out.println();
		System.out.println("0. 상위메뉴로");
	
	}
	
}

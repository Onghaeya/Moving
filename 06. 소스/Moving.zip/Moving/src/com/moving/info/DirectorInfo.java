package com.moving.info;

import java.util.ArrayList;

import com.moving.DTO.DirectorDTO;
import com.moving.booking.CinemaGetters;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.SearchUI;

/**
 * 감독 세부 정보 페이지
 * @author 해나
 *
 */
public class DirectorInfo extends CinemaGetters {

	public void info(String directorSeq) {
		
		boolean loop = true;
		
		DirectorDTO temp = new DirectorDTO();
		
		for(DirectorDTO d : Main.directorList) {
			if(d.getSeq().equals(directorSeq)) {
				temp = d;
				break;
			}
		}
				
		while (loop) {

			UI.clear();
			ArrayList<String> workList = getWorks(directorSeq, 0);
			ArrayList<String> prizeList = getPrizeList(directorSeq);
		
			UI.title("감독 상세정보");

			SearchUI.getSubMenu();
			
			//이름
			System.out.printf("\n< %s >\n\n", temp.getName());

			//나이
			System.out.println("★ 생일 : " + getYear(temp.getBirthday()) + "년 " + getKoreanDate(temp.getBirthday()));
			System.out.println();
			
			//국적
			System.out.printf("★ 국적 : " + getCountry(temp.getCountrySeq()));
			System.out.println();
			System.out.println();
			
			//필모
			System.out.println("★ 필모그래피");
			
			for(String s : workList) {
				System.out.println("   " + s);
			}
			System.out.println();
			
			
			//수상내역
			System.out.println("★ 수상내역");
			
			for(String s : prizeList) {
				System.out.println("   " + s);
			}
			System.out.println();
			
			System.out.println("★ 소개");
			System.out.println(" " + devideLine( temp.getInfo()));
			System.out.println();
			
			
			System.out.print("입력 > ");
			
			String sel = scan.nextLine();
			
			if(sel.equals("0")) {
				loop = false;
			}
		}
	}
		
}

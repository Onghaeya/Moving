package com.moving.admin.book;

import com.moving.main.UI;

public class AdministratorUI {

	/**
	 * 상영 영화 관리 메뉴
	 */
	static void getOnscreenMenu() {
		
			System.out.println("1. 상영영화 목록   2. 상영영화 삭제   3. 상영영화 추가   0. 상위메뉴로");
			UI.line();
		
	}
	/**
	 * 상영 영화 목록의 헤더
	 */
	public static void getMovieListHeader() {
		
		
		System.out.println("[번호]\t[제목]\t\t[연도]\t[장르]\t\t[감독]");
		UI.line();
	}
	
	/**
	 * 영화 메뉴를 얻는 메소드
	 */
	public static void getCinemaMenu() {
		System.out.println("1. 상영관 관리   2. 지역 관리   0. 상위메뉴로");
		UI.line();
		
	}
	
	/**
	 * 영화 예매 목록 메뉴
	 */
	public static void getTicketMenu() {
		System.out.println("1. 예매 목록   2. 예매 삭제");
		UI.line();
		
	}

	/**
	 * 회원별 예매 삭제 관련 메뉴
	 */
	public static void getCompanyMenu() {
		System.out.println("1. 회원별 예매 삭제\t2. 상영관별 예매 삭제");
		UI.line();
		
	}
}

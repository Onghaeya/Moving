package com.moving.admin.book;
import java.util.ArrayList;
import java.util.Scanner;

import com.moving.DTO.MovieDTO;
import com.moving.main.FileUtil;
import com.moving.main.Getters;
import com.moving.main.Main;
import com.moving.main.UI;
import com.moving.search.MovieSearch;
import com.moving.search.SearchUI;

/**
 * 예매 관리 
 * @author 해나
 *
 */
public class EditOnscreen extends Getters {
	/**
	 * 상영 영화의 식별 번호 목록
	 */
	public static ArrayList<String> seqList = new ArrayList<String>();

	/**
	 * 예매 관리 선택 메뉴
	 */
	public void onscreenMenu() {
		
		boolean loop = true;
		while(loop) {
			
			
			Scanner scan = new Scanner(System.in);
			UI.clear();
			UI.title("상영영화 관리");
			
			AdministratorUI.getOnscreenMenu();
			

			System.out.print("입력 > ");
			String sel = scan.nextLine();
			
			//"\n1. 상영영화 목록\t2. 상영영화 삭제\n3. 상영영화 추가");
			if(sel.equals("1")) {
				System.out.println();
				onscreenList();
				
			} else if(sel.equals("2")) {
				System.out.println();
				onscreenList(seqList);
				onscreenDelete(seqList);

			} else if(sel.equals("3")){
				
				MovieSearch m = new MovieSearch();
				m.search();		
				
				onscreenAdd(seqList);
				
			} else if(sel.equals("0")) {
				loop = false;
			} else {
				SearchUI.inputError();
			}
		}
	}
	
	/**
	 * 상영 영화 목록 출력
	 */
	public void onscreenList() {
		
		ArrayList<String> seqList = new ArrayList<String>();
		
		AdministratorUI.getMovieListHeader();
	
		
		for(MovieDTO m : Main.movieList) {
			if(m.getState().equals("1")) {
				System.out.printf("%5s\t%-10.7s   \t%s\t%-10s  \t%-87s\t%s\n"
						, m.getSeq()
						, m.getTitle()
						, getYear(m.getStartDay())
						, getGenre(m.getGenreSeq())
						, getDirector(m.getSeq())
						, getState(m.getSeq()));
			}
		}
		
		scan.nextLine();

	}
	
	/**
	 * 상영 영화 목록 출력
	 * @param seqList 영화 식별자 목록
	 */
	public void onscreenList(ArrayList<String> seqList) {
		

		AdministratorUI.getMovieListHeader();
		
		for(MovieDTO m : Main.movieList) {
			if(m.getState().equals("1")) {
				
				System.out.printf("%5s\t%-10.7s   \t%s\t%-10s  \t%-87s\t%s\n"
						, m.getSeq()
						, m.getTitle()
						, getYear(m.getStartDay())
						, getGenre(m.getGenreSeq())
						, getDirector(m.getSeq())
						, getState(m.getSeq()));

				seqList.add(m.getSeq());
			}
		}
		scan.nextLine();
	}
	
	/**
	 * 상영 영화 상태 변경 메소드
	 * @param seqList 상영 영화 식별 번호 목록
	 */
	public void onscreenDelete(ArrayList<String> seqList) {
		
		boolean loop = true;

		while(loop) {
			
			System.out.print("상영 상태를 변경할 영화의 번호를 입력하세요 > ");
			String movieSeq = scan.nextLine();
			
			if(seqList.contains(movieSeq)) {
				
				for(MovieDTO m : Main.movieList) {
					if(m.getSeq().equals(movieSeq)) {
						m.setState("0");
						FileUtil.movieSave();
						break;
					}
				}
				loop = false;
			
			} else {
				SearchUI.inputError();
			}
			
		}
		
	}
	
	/**
	 * 상영 목록에 영화를 추가하는 메소드
	 * @param seqList 상영 영화 식별 번호 목록
	 */
	public void onscreenAdd(ArrayList<String> seqList) {
		
		System.out.print("상영목록에 추가할 영화 번호 > ");
		String movieSeq = scan.nextLine();
		
		if(seqList.contains(movieSeq)) {
			
			for(MovieDTO m : Main.movieList) {
				if(m.getSeq().equals(movieSeq)) {
					m.setState("1");
					break;
				}
			}
		}
		FileUtil.movieSave();
		System.out.printf("%s을(를) 상영 목록에 추가했습니다.\n", getTitle(movieSeq));
	}

}



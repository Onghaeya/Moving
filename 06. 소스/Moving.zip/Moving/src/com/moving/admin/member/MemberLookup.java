package com.moving.admin.member;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 회원을 일람/확인 하는 화면
 * @author 박
 *
 */
class MemberLookup extends UI {

	/**
	 * 관리자의 회원 일람 실행 메소드
	 */
	void start() {
		
		MemberStatus memberStatus = new MemberStatus();
		boolean loop = true, loop2 = true;
		String sel = "";
		int i = 1;
		
		try {
			while (loop) {
				clear();
				title("회원일람 (관리자)");
				System.out.println("회원번호 : 회원상세정보  01.이전페이지  02.다음페이지  0.상위 메뉴로");
				line();
				System.out.println("회원번호 아이디\t\t이름\t생년월일");
				line();
				
				for (;i<Main.memberList.size();) {
					System.out.printf("%4s  %-12.12s  %-8s  %s", Main.memberList.get(i).getMemberSeq()
							, Main.memberList.get(i).getId(), Main.memberList.get(i).getName()
							, Main.memberList.get(i).getBirthday()+"\n");
					if (i%30==0) {
						i++;
						break;
					}
					if (i==Main.memberList.size()-1) {
						break;
					}
					i++;
				}
				loop2 = true;
				sel = pause();
				
				while (loop2) {
					if (i==Main.memberList.size()-1) {
						System.out.println("모든 회원이 검색되었습니다");
					}

					if (sel.equals(Main.memberList.get(Integer.parseInt(sel)).getMemberSeq()) && !sel.equals("1")) {
						memberStatus.start(sel);
						
						FileUtil.memberSave();
						
						i = 1;
						loop2 = false;
					} else if (sel.equals("1")) {
						memberStatus.start("1");
						
						FileUtil.memberSave();
						
						i = 0;
						loop2 = false;
					} else if (i>60 && sel.equals("01")) {
						i -= 60;
						loop2 = false;
					} else if (i<Main.memberList.size()-1 && sel.equals("02")) {
						loop2 = false;
					} else if (sel.equals("0")){
						loop2 = false;
						loop = false;
					} else {
						System.out.println("다시 입력해주세요");
						sel = pause();
					}
				}//loop2
			}//while
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}

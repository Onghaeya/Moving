package com.moving.admin.member;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 특정 이름을 가진 회원을 찾아 정보를 확인하는 화면
 * @author 박
 *
 */
class MemberSearch extends UI {

	MemberStatus memberStatus = new MemberStatus();
	
	/**
	 * 관리자의 회원 검색 실행 메소드 
	 * @param memberName 이전에 로그인 했을 시 저장되는 회원번호를 불러옴
	 */
	void start(String memberName) {
		
		boolean loop = true;
		boolean find = false;
		String sel = "";
		String memory = memberName;
		
		try {
			while (loop) {
				find = false;
				clear();
				title("회원 검색 (관리자)");
				System.out.println("회원번호 : 회원상세정보  00.재검색  0.상위 메뉴로");
				line();
				for(int i=0;i<Main.memberList.size();i++) {
					if (Main.memberList.get(i).getName().indexOf(memory) > -1) {
						System.out.print("회원번호 : "+Main.memberList.get(i).getMemberSeq()+
								"\t이름 : "+Main.memberList.get(i).getName()+
								"\t\t생년월일 : "+Main.memberList.get(i).getBirthday()+"\n");
						line();
						find = true;
					}
				}
				if (!find) {
					System.out.println("검색결과를 찾지 못했습니다");
					memory = searchPause();
					if (memory.equals("0")){
						loop = false;
					}
				}
				if (find) {
					sel = pause();
					if (sel.equals("0")) {
						loop = false;
					} else if (sel.equals("1")) {
						memberStatus.start("0");
						
						FileUtil.memberSave();
						
					} else if (sel.equals(Main.memberList.get(Integer.parseInt(sel)).getMemberSeq())) {
						memberStatus.start(sel);
						
						FileUtil.memberSave();
						
						memory = Main.memberList.get(Integer.parseInt(sel)).getName();
					} else if (sel.equals("00")){
						memory = searchPause();
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}

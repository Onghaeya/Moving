package com.moving.admin.member;

import com.moving.main.Join;
import com.moving.main.UI;

/**
 * 관리자가 회원 DB를 변경할 때 접근하는 첫 화면
 * @author 박
 *
 */
public class MemberMain extends UI {

	/**
	 * 관리자의 회원DB 메인 메소드
	 */
	public void start() {
		
		MemberLookup memberLookup = new MemberLookup();
		MemberSearch memberSearch = new MemberSearch();
		Join in = new Join();
		boolean loop = true;
		String sel = "";
		
		try {
			while (loop) {
				clear();
				title("회원DB (관리자)");
				System.out.println("1.회원일람  2.회원검색  3.회원추가  0.상위 메뉴로");
				line();
				sel = pause();
				
				if (sel.equals("1")) {
					memberLookup.start();
				} else if (sel.equals("2")) {
					sel = searchPause();
					memberSearch.start(sel);
				} else if (sel.equals("3")) {
					in.join(0);
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//start
}//MemberMain
package com.moving.admin.member;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 찾은 회원 1명의 DB를 확인하여 수정/삭제할 수 있는 화면
 * @author 박
 *
 */
class MemberStatus extends UI {

	/**
	 * 관리자의 회원 상세정보 확인 메소드 
	 * @param memberSeq 이전에 로그인 했을 시 저장되는 회원번호를 불러옴
	 */
	void start(String memberSeq) {	
		
		boolean loop = true;
		String sel = "";
		
		try {
			while (loop) {
				clear();
				title("회원 상세 정보 (관리자)");
				System.out.println("00.회원삭제  0.상위 메뉴로");
				line();
				System.out.printf("회원번호 : %s\nID : %s\t\t1.비밀번호 : %s\n2.이름 : %s\t\t3.생년월일 : %s\n4.메일 : %s\n5.전화 : %s\n",
						Main.memberList.get(Integer.parseInt(memberSeq)).getMemberSeq(), Main.memberList.get(Integer.parseInt(memberSeq)).getId(),
						Main.memberList.get(Integer.parseInt(memberSeq)).getPassword(), Main.memberList.get(Integer.parseInt(memberSeq)).getName(),
						Main.memberList.get(Integer.parseInt(memberSeq)).getBirthday(), Main.memberList.get(Integer.parseInt(memberSeq)).getEmail(),
						Main.memberList.get(Integer.parseInt(memberSeq)).getTel());
				sel = pause();
				
				if (sel.equals("1")) {
					sel = editPause();
					Main.memberList.get(Integer.parseInt(memberSeq)).setPassword(sel);
				} else if (sel.equals("2")) {
					sel = editPause();
					Main.memberList.get(Integer.parseInt(memberSeq)).setName(sel);
				} else if (sel.equals("3")) {
					System.out.println("생년월일 형식은 0000-00-00으로 지정해주세요");
					sel = editPause();
					Main.memberList.get(Integer.parseInt(memberSeq)).setBirthday(sel);
				} else if (sel.equals("4")) {
					sel = editPause();
					Main.memberList.get(Integer.parseInt(memberSeq)).setEmail(sel);
				} else if (sel.equals("5")) {
					sel = editPause();
					Main.memberList.get(Integer.parseInt(memberSeq)).setTel(sel);
				} else if (sel.equals("00")) {
					System.out.printf("정말로 이 회원을 삭제하시겠습니까? 원하시면 \"삭제\"를 입력하십시오\n");
					String reSel = editPause();
					if (reSel.equals("삭제")) {
						for (int i=0;i<Main.memberList.size();i++) {
							if (memberSeq.equals(Main.memberList.get(i).getMemberSeq())) {
								Main.memberList.remove(i);
							}
						}
						System.out.println("정상적으로 삭제되었습니다");
						enterPause();
						
						FileUtil.memberSave();
						
						loop = false;
					} else {}
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}

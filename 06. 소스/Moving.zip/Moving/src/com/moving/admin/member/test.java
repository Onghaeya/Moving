package com.moving.admin.member;

import com.moving.*;
import com.moving.main.FileUtil;

class test {

//	public static void main(String[] args) {
//		FileUtil.load();
//		com.moving.main.Main.main(args);
//		MemberMain mem = new MemberMain();
//		mem.start();
//	}
}

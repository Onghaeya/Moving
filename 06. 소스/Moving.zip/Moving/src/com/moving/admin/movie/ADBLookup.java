package com.moving.admin.movie;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 배우를 일람/확인 하는 화면
 * @author 박
 *
 */
class ADBLookup extends UI {

	/**
	 * 관리자의 배우 일람 수행 메소드
	 */
	void start() {

		ADBStatus adbStatus = new ADBStatus();
		boolean loop = true, loop2 = true;
		String sel = "";
		int find = 0;
		int i = 0;
		
		try {
			while (loop) {
				clear();
				title("배우일람 (관리자)");
				System.out.println("배우번호 : 배우상세정보  01.이전페이지  02.다음페이지  0.상위 메뉴로");
				line();
				System.out.println("배우번호 생년월일      이름        국적");
				line();
				for (;i<Main.actorList.size();) {
					System.out.printf("%4s     %10s  %s  %s\n", Main.actorList.get(i).getSeq(), Main.actorList.get(i).getBirth(), Main.actorList.get(i).getName(),
							Main.countryList.get(Integer.parseInt(Main.actorList.get(i).getCountrySeq())-1).getCountry());
					if (i%30==0 && i!=0) {
						i++;
						break;
					}
					if (i==Main.actorList.size()-1) {
						break;
					}
					i++;
				}
				loop2 = true;
				sel = pause();
				if (!sel.equals("0")) {
					find = Integer.parseInt(sel)-1;
				}
				
				while (loop2) {
					if (i==Main.actorList.size()-1) {
						System.out.println("모든 배우가 검색되었습니다");
					}

					if (sel.equals(Main.actorList.get(find).getSeq()) && !sel.equals("1")) {
						adbStatus.start(find);

						FileUtil.artistSave();
						
						i = 0;
						loop2 = false;
					} else if (sel.equals("1")) {
						adbStatus.start(0);

						FileUtil.artistSave();
						
						i = 0;
						loop2 = false;
					} else if (i>59 && sel.equals("01")) {
						i -= 60;
						loop2 = false;
					} else if (i<Main.actorList.size()-1 && sel.equals("02")) {
						loop2 = false;
					} else if (sel.equals("0")){
						loop2 = false;
						loop = false;
					} else {
						sel = pause();
					}
				}//loop2
			}//while
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBLookup

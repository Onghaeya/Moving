package com.moving.admin.movie;

import com.moving.DTO.ActorDTO;
import com.moving.DTO.ActorFilmoDTO;
import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 배우정보를 추가하는 화면
 * @author 박
 *
 */
class ADBAdd extends UI {

	/**
	 * 관리자의 배우 추가 수행 메소드
	 */
	void start() {
		
		MDBSearch mdbSearch = new MDBSearch();
		ADBSearch adbSearch = new ADBSearch();
		boolean loop = true;
		boolean loop2 = true;
		String sel = "";
		String name = "", country = "", birthday = "", profile = "";
		int dseq = 0;
		try {
			while (loop) {
				clear();
				title("배우 추가 (관리자)");
				System.out.println("1.배우추가  2.배우 필모그래피 추가  0.상위 메뉴로");
				line();
				sel = pause();
				if (sel.equals("1")) {
					ActorDTO addDTO = new ActorDTO();
					
					dseq = Integer.parseInt(Main.actorList.get(Main.actorList.size()-1).getSeq())+1;
					addDTO.setSeq(dseq+"");
					
					name = namedPause("배우 이름을 입력하세요");
					addDTO.setName(name);
					
					for (int i=0;i<Main.countryList.size();i++) {
						System.out.printf(Main.countryList.get(i).getSeq()+" "+Main.countryList.get(i).getCountry()+"/");
						if (i%10==0 && i!=0){
							System.out.println();
						}
					}
					country = namedPause("\n국가번호를 입력하세요");
					addDTO.setCountrySeq(country);
					
					birthday = namedPause("배우의 생년월일을 입력하세요(형식은 0000-00-00)");
					addDTO.setBirth(birthday);
					
					profile = namedPause("배우의 프로필을 입력하세요");
					addDTO.setProfile(profile);
					
					Main.actorList.add(addDTO);
					System.out.println("배우가 추가되었습니다");

					FileUtil.artistSave();
					
				} else if (sel.equals("2")) {
					ActorFilmoDTO addFilmoDTO = new ActorFilmoDTO();
					
					sel = namedPause("검색할 배우 이름을 입력하세요");
					dseq = Integer.parseInt(adbSearch.startFilmo(sel));
					addFilmoDTO.setActorSeq(dseq+"");
					
					sel = namedPause("검색할 영화 이름을 입력하세요");
					dseq = Integer.parseInt(mdbSearch.startFilmo(sel));
					addFilmoDTO.setMovieSeq(dseq+"");
					
					while (loop2) {
						System.out.println("배우의 출연 형태를 입력하세요");
						sel = namedPause("주연 : A   조연 : B");
						if (sel.equals("A") || sel.equals("B")) {
							loop2 = false;
						} else {
							System.out.println("A와 B만 입력 가능합니다. 정확히 입력해주세요");
						}
					}
					addFilmoDTO.setMovieRole(sel);
					
					Main.actorFilmoList.add(addFilmoDTO);

					FileUtil.artistSave();
					
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBAdd
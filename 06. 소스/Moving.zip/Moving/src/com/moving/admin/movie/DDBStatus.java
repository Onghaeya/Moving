package com.moving.admin.movie;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 찾은 감독 1명의 DB를 확인하여 수정/삭제할 수 있는 화면
 * @author 박
 *
 */
public class DDBStatus extends UI {

	/**
	 * 감독의 상세정보 출력 수행 메소드
	 * @param seq 상세정보를 출력할 감독 번호를 가져옴
	 */
	void start(int seq) {
		
		boolean loop = true;
		String sel = "";
		try {
			while (loop) {
				clear();
				title("감독 상세 정보 (관리자)");
				System.out.println("00.감독삭제  0.상위 메뉴로");
				line();
				System.out.printf("감독번호 : %s 1.이름 : %s\n"+ "2.국적 : %s 3.생년월일 : %s\n", 
						Main.directorList.get(seq).getSeq(), Main.directorList.get(seq).getName(),
						Main.countryList.get(Integer.parseInt(Main.directorList.get(seq).getCountrySeq())-1).getCountry(),
						Main.directorList.get(seq).getBirthday());
				System.out.println("필모그래피");
				for (int i=0;i<Main.directorFilmoList.size();i++) {
					if ((seq+"").equals(Main.directorFilmoList.get(i).getDirectorSeq())) {
						System.out.println(Main.movieList.get(Integer.parseInt(Main.directorFilmoList.get(i).getMovieSeq())).getTitle());
					}
				}
				sel = pause();
				
				if (sel.equals("1")) {
					sel = editPause();
					Main.directorList.get(seq).setName(sel);
				} else if (sel.equals("2")) {
					for (int i=0;i<Main.countryList.size();i++) {
						System.out.printf(Main.countryList.get(i).getSeq()+" "+Main.countryList.get(i).getCountry()+"/");
						if (i%10==0 && i!=0){
							System.out.println();
						}
					}
					System.out.println();
					sel = editPause();
					Main.directorList.get(seq).setCountrySeq(sel);
				} else if (sel.equals("3")) {
					System.out.println("생년월일 형식은 0000-00-00으로 지정해주세요");
					sel = editPause();
					Main.directorList.get(seq).setBirthday(sel);
				} else if (sel.equals("00")) {
					System.out.printf("정말로 이 감독을 삭제하시겠습니까? 원하시면 \"삭제\"를 입력하십시오\n");
					String reSel = editPause();
					if (reSel.equals("삭제")) {
						for (int i=0;i<Main.directorList.size();i++) {
							if ((seq+"").equals(Main.directorList.get(i).getSeq())) {
								Main.directorList.remove(i);
							}
						}
						System.out.println("정상적으로 삭제되었습니다");
						enterPause();
						
						FileUtil.artistSave();
						
						loop = false;
					} else {}
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBStatus
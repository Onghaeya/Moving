package com.moving.admin.movie;

import com.moving.main.UI;

/**
 * 관리자가 배우 DB를 변경할 때 접근하는 첫 화면
 * @author 박
 *
 */
class ADBMain extends UI {

	/**
	 * 관리자의 배우DB 접근 시 첫 화면과 분기 수행 메소드
	 */
	void start() {
		
		ADBLookup adbLookup = new ADBLookup();
		ADBSearch adbSearch = new ADBSearch();
		ADBAdd adbAdd = new ADBAdd();
		ADBFilmo adbFilmo = new ADBFilmo();
		boolean loop = true;
		String sel = "";
		
		try {
			while (loop) {
				clear();
				title("배우 DB (관리자)");
				System.out.println("1.배우일람  2.배우검색  3.배우추가  4.배우 필모그래피 일람/수정  0.상위 메뉴로");
				line();
				sel = pause();

				if (sel.equals("1")) {
					adbLookup.start();
				} else if (sel.equals("2")) {
					sel = searchPause();
					adbSearch.start(sel);
				} else if (sel.equals("3")) {
					adbAdd.start();
				} else if (sel.equals("4")) {
					adbFilmo.start();
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}
package com.moving.admin.movie;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 찾은 영화 1개의 DB를 확인하여 수정/삭제할 수 있는 화면
 * @author 박
 *
 */
public class MDBStatus extends UI {

	/**
	 * 영화의 상세정보 출력 수행 메소드
	 * @param seq 상세정보를 출력할 영화 번호를 가져옴
	 */
	void start(int seq) {
		
		boolean loop = true;
		boolean loop2 = true;
		String sel = "";
		
		try {
			while (loop) {
				clear();
				title("영화 상세 정보 (관리자)");
				System.out.println("00.영화삭제  0.상위 메뉴로");
				line();
				System.out.printf("영화번호 : %s\n1.제목 : %s\n"+ "2.개봉일 : %s 3.장르 : %s\t4.국적 : %s\n"
						+ "5.관객수 : %,d 6.등급 : %s 7.개봉상태 : %s\n"
						+ "8.예고편링크 9.줄거리 : %s\n",Main.movieList.get(seq).getSeq(), Main.movieList.get(seq).getTitle(),
						Main.movieList.get(seq).getStartDay(), Main.genreList.get(Integer.parseInt(Main.movieList.get(seq).getGenreSeq())-1).getGenre(),
						Main.countryList.get(Integer.parseInt(Main.movieList.get(seq).getCountrySeq())-1).getCountry(),
						Main.movieList.get(seq).getAudience(), Main.gradeList.get(Integer.parseInt(Main.movieList.get(seq).getGradeSeq())-1).getGrade(),
						Main.movieList.get(seq).getState(), Main.movieList.get(seq).getSynopsis());
				sel = pause();
				
				if (sel.equals("1")) {
					sel = editPause();
					Main.movieList.get(seq).setTitle(sel);
				} else if (sel.equals("2")) {
					System.out.println("개봉일 형식은 0000-00-00으로 지정해주세요");
					sel = editPause();
					Main.movieList.get(seq).setStartDay(sel);
				} else if (sel.equals("3")) {
					for (int i=0;i<Main.genreList.size();i++) {
						System.out.printf(Main.genreList.get(i).getSeq()+"  "+Main.genreList.get(i).getGenre()+"\n");
					}
					sel = editPause();
					Main.movieList.get(seq).setGenreSeq(sel);
				} else if (sel.equals("4")) {
					for (int i=0;i<Main.countryList.size();i++) {
						System.out.printf(Main.countryList.get(i).getSeq()+" "+Main.countryList.get(i).getCountry()+"/");
						if (i%10==0 && i!=0){
							System.out.println();
						}
					}
					System.out.println();
					sel = editPause();
					Main.movieList.get(seq).setCountrySeq(sel);
				} else if (sel.equals("5")) {
					sel = editPause();
					Main.movieList.get(seq).setAudience(Integer.parseInt(sel));
				} else if (sel.equals("6")) {
					for (int i=0;i<Main.gradeList.size();i++) {
						System.out.printf(Main.gradeList.get(i).getSeq()+" "+Main.gradeList.get(i).getGrade()+"\n");
					}
					sel = editPause();
					Main.movieList.get(seq).setGradeSeq(sel);
				} else if (sel.equals("7")) {
					System.out.println("0 : 미개봉    1 : 개봉중");
					while (loop2) {
						sel = editPause();
						if (sel.equals("0") || sel.equals("1")) {
							Main.movieList.get(seq).setState(sel);
							loop2 = false;
						}
					}
				} else if (sel.equals("8")) {
					sel = editPause();
					Main.movieList.get(seq).setTrailer(sel);
				} else if (sel.equals("9")) {
					System.out.println();
					sel = editPause();
					Main.movieList.get(seq).setSynopsis(sel);
				} else if (sel.equals("00")) {
					System.out.printf("정말로 이 영화를 삭제하시겠습니까? 원하시면 \"삭제\"를 입력하십시오\n");
					String reSel = editPause();
					if (reSel.equals("삭제")) {
						for (int i=0;i<Main.movieList.size();i++) {
							if ((seq+"").equals(Main.movieList.get(i).getSeq())) {
								Main.movieList.remove(i);
							}
						}
						System.out.println("정상적으로 삭제되었습니다");
						enterPause();
						
						FileUtil.movieSave();
						
						loop = false;
					} else {}
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBStatus
package com.moving.admin.movie;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 특정 이름을 가진 감독을 찾아 정보를 확인하는 화면
 * @author 박
 *
 */
public class DDBSearch extends UI {

	/**
	 * 관리자의 감독 검색 수행 메소드
	 * @param directorName 감독DB와 비교하기 위해 가져온 이전에 입력받은 검색어
	 */
	void start(String directorName) {
		
		DDBStatus ddbStatus = new DDBStatus();
		boolean loop = true;
		boolean find = false;
		String sel = "";
		String memory = directorName;
		
		try {
			while (loop) {
				find = false;
				clear();
				title("감독 검색 (관리자)");
				System.out.println("감독번호 : 감독상세정보  00.재검색  0.상위 메뉴로");
				line();
				for(int i=0;i<Main.directorList.size();i++) {
					if (Main.directorList.get(i).getName().indexOf(memory) > -1) {
						System.out.print("감독번호 : "+Main.directorList.get(i).getSeq()+
								" 이름 : "+Main.directorList.get(i).getName()+
								"\n국적 : "+Main.countryList.get(Integer.parseInt(Main.directorList.get(i).getCountrySeq())-1).getCountry()+
								" 생년월일 : "+Main.directorList.get(i).getBirthday()+"\n");
						line();
						find = true;
					}
				}
				if (!find) {
					System.out.println("검색결과를 찾지 못했습니다");
					memory = searchPause();
					if (memory.equals("0")){
						loop = false;
					}
				}
				if (find) {
					sel = pause();
					if (sel.equals("0")) {
						loop = false;
					} else if (sel.equals("1")) {
						ddbStatus.start(0);

						FileUtil.artistSave();
						
					} else if (sel.equals(Main.directorList.get(Integer.parseInt(sel)-1).getSeq())) {
						ddbStatus.start(Integer.parseInt(sel)-1);

						FileUtil.artistSave();
						
						memory = Main.directorList.get(Integer.parseInt(sel)-1).getName();
					} else if (sel.equals("00")){
						memory = searchPause();
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//start
	
	/**
	 * 감독의 필모그래피를 가져오기 위한 작업 수행
	 * @param directorName 감독DB와 비교하기 위해 가져온 이전에 입력받은 검색어
	 * @return 다른 데이터 검색에서 사용하기 위해 검색된 감독번호를 돌려줌
	 */
	String startFilmo (String directorName) {
		
		boolean loop = true;
		boolean find = false;
		String sel = "";
		String memory = directorName;
		
		try {
			while (loop) {
				find = false;
				clear();
				title("감독번호 검색 (관리자)");
				System.out.println("감독번호선택  00.재검색");
				line();
				for(int i=0;i<Main.directorList.size();i++) {
					if (memory.equals(Main.directorList.get(i).getName())) {
						System.out.print("감독번호 : "+Main.directorList.get(i).getSeq()+
								" 이름 : "+Main.directorList.get(i).getName()+
								"\n국적 : "+Main.countryList.get(Integer.parseInt(Main.directorList.get(i).getCountrySeq())-1).getCountry()+
								" 생년월일 : "+Main.directorList.get(i).getBirthday()+"\n");
						line();
						find = true;
					}
				}
				if (!find) {
					System.out.println("검색결과를 찾지 못했습니다");
					memory = searchPause();
				}
				if (find) {
					sel = namedPause("검색된 감독번호를 입력하세요 > ");
					if (sel.equals("00")){
						memory = searchPause();
					}
					loop = false;
					return sel;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}//startFilmo
	
}//MDBSearch
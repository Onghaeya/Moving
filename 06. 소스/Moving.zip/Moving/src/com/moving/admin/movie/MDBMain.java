package com.moving.admin.movie;

import com.moving.main.UI;

/**
 * 관리자가 영화 DB를 변경할 때 접근하는 첫 화면
 * @author 박
 *
 */
class MDBMain extends UI {

	/**
	 * 관리자의 영화DB 접근 시 첫 화면과 분기 수행 메소드
	 */
	void start() {
		
		MDBLookup mdbLookup = new MDBLookup();
		MDBSearch mdbSearch = new MDBSearch();
		MDBAdd mdbAdd = new MDBAdd();
		boolean loop = true;
		String sel = "";
		
		try {
			while (loop) {
				clear();
				title("영화 DB (관리자)");
				System.out.println("1.영화일람  2.영화검색  3.영화추가  0.상위 메뉴로");
				line();
				sel = pause();
				
				if (sel.equals("1")) {
					mdbLookup.start();
				} else if (sel.equals("2")) {
					sel = searchPause();
					mdbSearch.start(sel);
				} else if (sel.equals("3")) {
					mdbAdd.start();
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}//MDBMain
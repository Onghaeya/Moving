package com.moving.admin.movie;

import com.moving.main.UI;

/**
 * 관리자가 영화와 영화인의 DB를 변경할 때 접근하는 첫 화면
 * @author 박
 *
 */
public class MovieMain extends UI {

	/**
	 * 관리자의 영화DB 메인 메소드
	 */
	public void start() {
		
		MDBMain mdbMain = new MDBMain();
		DDBMain ddbMain = new DDBMain();
		ADBMain adbMain = new ADBMain();
		boolean loop = true;
		String sel = "";
		
		try {
			while (loop) {
				title("영화관련 DB (관리자)");
				System.out.println("1.영화 DB 업무  2.감독 DB 업무  3.배우 DB 업무  0.상위 메뉴로");
				line();
				sel = pause();
				
				if (sel.equals("1")) {
					mdbMain.start();
				} else if (sel.equals("2")) {
					ddbMain.start();
				} else if (sel.equals("3")) {
					adbMain.start();
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//start
}//MovieMain
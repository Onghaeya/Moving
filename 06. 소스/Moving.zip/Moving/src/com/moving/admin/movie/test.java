package com.moving.admin.movie;

import com.moving.*;
import com.moving.main.FileUtil;

class test {

//	public static void main(String[] args) {
//		FileUtil.load();
//		com.moving.main.Main.main(args);
//		MovieMain mem = new MovieMain();
//		mem.start();
//	}
}

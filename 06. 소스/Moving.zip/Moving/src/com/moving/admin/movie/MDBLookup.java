package com.moving.admin.movie;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 영화를 일람/확인 하는 화면
 * @author 박
 *
 */
class MDBLookup extends UI {

	/**
	 * 관리자의 영화 일람 수행 메소드
	 */
	void start() {

		MDBStatus mdbStatus = new MDBStatus();
		boolean loop = true, loop2 = true;
		String sel = "";
		int find = 0;
		int i = 0;
		
		try {
			while (loop) {
				clear();
				title("영화일람 (관리자)");
				System.out.println("영화번호 : 영화상세정보  01.이전페이지  02.다음페이지  0.상위 메뉴로");
				line();
				System.out.println("영화번호 연도    장르      국적\t\t\t\t제목");
				line();
				for (;i<Main.movieList.size();) {
					System.out.printf("%4s    %4.4s %s %10.10s %36s", Main.movieList.get(i).getSeq(), Main.movieList.get(i).getStartDay(),
							Main.genreList.get(Integer.parseInt(Main.movieList.get(i).getGenreSeq())-1).getGenre(),
							Main.countryList.get(Integer.parseInt(Main.movieList.get(i).getCountrySeq())-1).getCountry(), Main.movieList.get(i).getTitle()+"\n");
					if (i%30==0 && i!=0) {
						i++;
						break;
					}
					if (i==Main.movieList.size()-1) {
						break;
					}
					i++;
				}
				loop2 = true;
				sel = pause();
				if (!sel.equals("0")) {
					find = Integer.parseInt(sel)-1;
				}
				
				while (loop2) {
					if (i==Main.movieList.size()-1) {
						System.out.println("모든 영화가 검색되었습니다");
					}

					if (sel.equals(Main.movieList.get(find).getSeq()) && !sel.equals("1")) {
						mdbStatus.start(find);

						FileUtil.movieSave();
						
						i = 0;
						loop2 = false;
					} else if (sel.equals("1")) {
						mdbStatus.start(0);
						
						FileUtil.movieSave();
						
						i = 0;
						loop2 = false;
					} else if (i>58 && sel.equals("01")) {
						i -= 60;
						loop2 = false;
					} else if (i<Main.movieList.size()-1 && sel.equals("02")) {
						loop2 = false;
					} else if (sel.equals("0")){
						loop2 = false;
						loop = false;
					} else {
						sel = pause();
					}
				}//loop2
			}//while
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBLookup

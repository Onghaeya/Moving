package com.moving.admin.movie;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 찾은 배우 1명의 DB를 확인하여 수정/삭제할 수 있는 화면
 * @author 박
 *
 */
public class ADBStatus extends UI {

	/**
	 * 배우의 상세정보 출력 수행 메소드 
	 * @param seq 상세정보를 출력할 배우 번호를 가져옴
	 */
	void start(int seq) {
		
		boolean loop = true;
		String sel = "";
		try {
			while (loop) {
				clear();
				title("배우 상세 정보 (관리자)");
				System.out.println("00.배우삭제  0.상위 메뉴로");
				line();
				System.out.printf("배우번호 : %s 1.이름 : %s\n"+ "2.국적 : %s 3.생년월일 : %s\n4.프로필 : %s\n", 
						Main.actorList.get(seq).getSeq(), Main.actorList.get(seq).getName(),
						Main.countryList.get(Integer.parseInt(Main.actorList.get(seq).getCountrySeq())-1).getCountry(),
						Main.actorList.get(seq).getBirth(), Main.actorList.get(seq).getProfile());
				System.out.println("필모그래피");
				for (int i=0;i<Main.actorFilmoList.size();i++) {
					if ((seq+"").equals(Main.actorFilmoList.get(i).getActorSeq())) {
						System.out.println(Main.movieList.get(Integer.parseInt(Main.actorFilmoList.get(i).getMovieSeq())).getTitle());
					}
				}
				sel = pause();
				
				if (sel.equals("1")) {
					sel = editPause();
					Main.actorList.get(seq).setName(sel);
				} else if (sel.equals("2")) {
					for (int i=0;i<Main.countryList.size();i++) {
						System.out.printf(Main.countryList.get(i).getSeq()+" "+Main.countryList.get(i).getCountry()+"/");
						if (i%10==0 && i!=0){
							System.out.println();
						}
					}
					System.out.println();
					sel = editPause();
					Main.actorList.get(seq).setCountrySeq(sel);
				} else if (sel.equals("3")) {
					System.out.println("생년월일 형식은 0000-00-00으로 지정해주세요");
					sel = editPause();
					Main.actorList.get(seq).setBirth(sel);
				} else if (sel.equals("4")) {
					sel = editPause();
					Main.actorList.get(seq).setProfile(sel);
				} else if (sel.equals("00")) {
					System.out.printf("정말로 이 배우를 삭제하시겠습니까? 원하시면 \"삭제\"를 입력하십시오\n");
					String reSel = editPause();
					if (reSel.equals("삭제")) {
						for (int i=0;i<Main.actorList.size();i++) {
							if ((seq+"").equals(Main.actorList.get(i).getSeq())) {
								Main.actorList.remove(i);
							}
						}
						System.out.println("정상적으로 삭제되었습니다");
						enterPause();
						
						FileUtil.artistSave();
						
						loop = false;
					} else {}
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBStatus
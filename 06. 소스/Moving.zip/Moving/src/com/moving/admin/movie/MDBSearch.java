package com.moving.admin.movie;

import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 특정 이름을 가진 영화를 찾아 정보를 확인하는 화면
 * @author 박
 *
 */
public class MDBSearch extends UI {

	/**
	 * 관리자의 영화 검색 수행 메소드
	 * @param movieName 영화DB와 비교하기 위해 가져온 이전에 입력받은 검색어
	 */
	void start(String movieName) {
		
		MDBStatus mdbStatus = new MDBStatus();
		boolean loop = true;
		boolean find = false;
		String sel = "";
		String memory = movieName;
		
		try {
			while (loop) {
				find = false;
				clear();
				title("영화 검색 (관리자)");
				System.out.println("영화번호 : 영화상세정보  00.재검색  0.상위 메뉴로");
				line();
				for(int i=0;i<Main.movieList.size();i++) {
					if (Main.movieList.get(i).getTitle().indexOf(memory) > -1) {
						System.out.print("영화번호 : "+Main.movieList.get(i).getSeq()+
								"\n개봉일 : "+Main.movieList.get(i).getStartDay()+
								" 국적 : "+Main.countryList.get(Integer.parseInt(Main.movieList.get(i).getCountrySeq())-1).getCountry()+
								" 장르 : "+Main.genreList.get(Integer.parseInt(Main.movieList.get(i).getGenreSeq())-1).getGenre()+
								"\n제목 : "+Main.movieList.get(i).getTitle()+"\n");
						line();
						find = true;
					}
				}
				if (!find) {
					System.out.println("검색결과를 찾지 못했습니다");
					memory = searchPause();
					if (memory.equals("0")){
						loop = false;
					}
				}
				if (find) {
					sel = pause();
					if (sel.equals("0")) {
						loop = false;
					} else if (sel.equals("1")) {
						mdbStatus.start(0);
						
						FileUtil.movieSave();
						
					} else if (sel.equals(Main.movieList.get(Integer.parseInt(sel)-1).getSeq())) {
						mdbStatus.start(Integer.parseInt(sel)-1);
						
						FileUtil.movieSave();
						
						memory = Main.movieList.get(Integer.parseInt(sel)-1).getTitle();
					} else if (sel.equals("00")){
						memory = searchPause();
					}
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}//start
	
	/**
	 * 해당 영화와 관련된 필모그래피를 가져오기 위한 작업 수행
	 * @param movieName 영화DB와 비교하기 위해 가져온 이전에 입력받은 검색어
	 * @return 다른 데이터 검색에서 사용하기 위해 검색된 영화번호를 돌려줌
	 */
	String startFilmo (String movieName) {
		
		boolean loop = true;
		boolean find = false;
		String sel = "";
		String memory = movieName;
		
		try {
			while (loop) {
				find = false;
				clear();
				title("영화번호 검색 (관리자)");
				System.out.println("영화번호선택  00.재검색");
				line();
				for(int i=0;i<Main.movieList.size();i++) {
					if (memory.equals(Main.movieList.get(i).getTitle())) {
						System.out.print("영화번호 : "+Main.movieList.get(i).getSeq()+
								"\n개봉일 : "+Main.movieList.get(i).getStartDay()+
								" 국적 : "+Main.countryList.get(Integer.parseInt(Main.movieList.get(i).getCountrySeq())-1).getCountry()+
								" 장르 : "+Main.genreList.get(Integer.parseInt(Main.movieList.get(i).getGenreSeq())-1).getGenre()+
								"\n제목 : "+Main.movieList.get(i).getTitle()+"\n");
						line();
						find = true;
					}
				}
				if (!find) {
					System.out.println("검색결과를 찾지 못했습니다");
					memory = searchPause();
				}
				if (find) {
					sel = namedPause("검색된 영화번호를 입력하세요 > ");
					if (sel.equals("00")){
						memory = searchPause();
					}
					loop = false;
					return sel;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}//startFilmo
	
}//MDBSearch
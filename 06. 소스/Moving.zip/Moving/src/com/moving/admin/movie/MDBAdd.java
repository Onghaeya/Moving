package com.moving.admin.movie;

import com.moving.DTO.MovieDTO;
import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 영화정보를 추가하는 화면
 * @author 박
 *
 */
class MDBAdd extends UI {

	/**
	 * 관리자의 영화 추가 수행 메소드
	 */
	void start() {
		
		boolean loop = true;
		String sel = "";
		String title = "", day = "", genre = "", country = "", grade = "", state = "", link = "", story = ""; 
		int moseq = 0, aud = 0, totalS = 0, totalA = 0; 
		
		try {
			while (loop) {
				clear();
				title("영화 추가 (관리자)");
				System.out.println("1.영화 추가  0.상위 메뉴로");
				line();
				sel = pause();
				if (sel.equals("1")) {
					MovieDTO addDTO = new MovieDTO();
					
					moseq = Integer.parseInt(Main.movieList.get(Main.movieList.size()-1).getSeq())+1;
					addDTO.setSeq(moseq+"");
					
					title = namedPause("영화 제목을 입력하세요");
					addDTO.setTitle(title);
					
					day = namedPause("개봉일을 입력하세요(형식은 0000-00-00)");
					addDTO.setStartDay(day);
					
					for (int i=0;i<Main.genreList.size();i++) {
						System.out.printf("장르번호 : "+Main.genreList.get(i).getSeq()+" 장르명 : "+Main.genreList.get(i).getGenre()+"\n");
					}
					genre = namedPause("장르번호를 입력하세요");
					addDTO.setGenreSeq(genre);
					
					for (int i=0;i<Main.countryList.size();i++) {
						System.out.printf(Main.countryList.get(i).getSeq()+" "+Main.countryList.get(i).getCountry()+"/");
						if (i%10==0 && i!=0){
							System.out.println();
						}
					}
					country = namedPause("국가번호를 입력하세요");
					addDTO.setCountrySeq(country);
					
					aud = Integer.parseInt(namedPause("관객수를 입력하세요"));
					addDTO.setAudience(aud);
					
					for (int i=0;i<Main.gradeList.size();i++) {
						System.out.printf(Main.gradeList.get(i).getSeq()+" "+Main.gradeList.get(i).getGrade()+"\n");
					}
					grade = namedPause("등급번호를 입력하세요");
					addDTO.setGradeSeq(grade);
					
					state = namedPause("개봉상태(0 : 개봉 안함  1 : 개봉중)");
					addDTO.setState(state);
					
					addDTO.setTotalScore(totalS);
					addDTO.setReviewerNum(totalA);
					
					link = namedPause("예고편의 링크주소를 입력하세요");
					addDTO.setTrailer(link);
					
					story = namedPause("줄거리를 입력하세요");
					addDTO.setSynopsis(story);
					
					Main.movieList.add(addDTO);
					System.out.println("영화가 추가되었습니다");
					
					FileUtil.movieSave();
					
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBAdd
package com.moving.admin.movie;

import com.moving.DTO.DirectorDTO;
import com.moving.DTO.DirectorFilmoDTO;
import com.moving.main.FileUtil;
import com.moving.main.Main;
import com.moving.main.UI;

/**
 * 관리자가 감독정보를 추가하는 화면
 * @author 박
 *
 */
class DDBAdd extends UI {

	/**
	 * 관리자의 감독 추가 수행 메소드
	 */
	void start() {
		
		MDBSearch mdbSearch = new MDBSearch();
		DDBSearch ddbSearch = new DDBSearch();
		boolean loop = true;
		String sel = "";
		String name = "", country = "", birthday = "";
		int dseq = 0;
		try {
			while (loop) {
				clear();
				title("감독 추가 (관리자)");
				System.out.println("1.감독 추가  2.감독 필모그래피 추가  0.상위 메뉴로");
				line();
				sel = pause();
				if (sel.equals("1")) {
					DirectorDTO addDTO = new DirectorDTO();
					
					dseq = Integer.parseInt(Main.directorList.get(Main.directorList.size()-1).getSeq())+1;
					addDTO.setSeq(dseq+"");
					
					name = namedPause("감독 이름을 입력하세요");
					addDTO.setName(name);
					
					for (int i=0;i<Main.countryList.size();i++) {
						System.out.printf(Main.countryList.get(i).getSeq()+" "+Main.countryList.get(i).getCountry()+"/");
						if (i%10==0 && i!=0){
							System.out.println();
						}
					}
					country = namedPause("국가번호를 입력하세요");
					addDTO.setCountrySeq(country);
					
					birthday = namedPause("감독의 생년월일을 입력하세요(형식은 0000-00-00)");
					addDTO.setBirthday(birthday);
					
					Main.directorList.add(addDTO);
					System.out.println("감독이 추가되었습니다");

					FileUtil.artistSave();
					
				} else if (sel.equals("2")) {
					DirectorFilmoDTO addFilmoDTO = new DirectorFilmoDTO();
					
					sel = namedPause("검색할 감독 이름을 입력하세요");
					dseq = Integer.parseInt(ddbSearch.startFilmo(sel));
					addFilmoDTO.setDirectorSeq(dseq+"");
					
					sel = namedPause("검색할 영화 이름을 입력하세요");
					dseq = Integer.parseInt(mdbSearch.startFilmo(sel));
					addFilmoDTO.setMovieSeq(dseq+"");
					
					Main.directorFilmoList.add(addFilmoDTO);

					FileUtil.artistSave();
					
				} else if (sel.equals("0")) {
					loop = false;
				}
			}
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
}//MDBAdd
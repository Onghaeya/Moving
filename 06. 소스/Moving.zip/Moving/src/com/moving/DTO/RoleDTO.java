package com.moving.DTO;

/**
 * 영화배우 영화 참여 형태 DTO
 * @author 유기태
 * 
 */
 
public class RoleDTO {

	private String seq;		//번호
	private String role;	//참여형태(주연,조연)
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

}

package com.moving.DTO;

/**
 * 영화관 DTO
 * @author 유기태
 * 
 */
 
public class CompanyDTO {

	private String companySeq;
	private String company;
	
	public String getCompanySeq() {
		return companySeq;
	}
	public void setCompanySeq(String companySeq) {
		this.companySeq = companySeq;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
	@Override
	public String toString() {
		return String.format("companySeq : %s, company : %s", companySeq, company);
	}
	
}

package com.moving.DTO;

/**
 * 영화별 키워드 DTO
 * @author 유기태
 * 
 */
 
public class MovieKeyDTO {

	private String movieSeq;
	private String keywordSeq;
	
	public String getMovieSeq() {
		return movieSeq;
	}
	public void setMovieSeq(String movieSeq) {
		this.movieSeq = movieSeq;
	}
	public String getKeywordSeq() {
		return keywordSeq;
	}
	public void setKeywordSeq(String keywordSeq) {
		this.keywordSeq = keywordSeq;
	}
	
	
	
}

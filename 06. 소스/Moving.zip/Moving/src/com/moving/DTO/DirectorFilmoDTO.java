package com.moving.DTO;

/**
 * 감독 필모그래피 DTO
 * @author 유기태
 * 
 */
 
public class DirectorFilmoDTO {
	
	private String directorSeq;
	private String movieSeq;
	
	public String getDirectorSeq() {
		return directorSeq;
	}
	public void setDirectorSeq(String directorSeq) {
		this.directorSeq = directorSeq;
	}
	public String getMovieSeq() {
		return movieSeq;
	}
	public void setMovieSeq(String movieSeq) {
		this.movieSeq = movieSeq;
	}
	
	@Override
	public String toString() {
	
		return String.format("%s %s", directorSeq, movieSeq);
	}
	
}

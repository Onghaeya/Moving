package com.moving.DTO;

/**
 * 영화제 상 DTO
 * @author 유기태
 * 
 */
 
public class PrizeTypeDTO {

	private String seq;
	private String prizeType;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getPrizeType() {
		return prizeType;
	}
	public void setPrizeType(String prizeType) {
		this.prizeType = prizeType;
	}
	
	
}

package com.moving.DTO;

/**
 * 영화 등급 DTO
 * @author 유기태
 * 
 */
 
public class GradeDTO {

	private String seq;
	private String grade;//영화 등급
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	
	
}

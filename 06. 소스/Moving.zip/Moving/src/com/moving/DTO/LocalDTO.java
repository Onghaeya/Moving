package com.moving.DTO;

/**
 * 지역 DTO
 * @author 유기태
 * 
 */
 
public class LocalDTO {

	private String localSeq;
	private String local;
	
	public String getLocalSeq() {
		return localSeq;
	}
	public void setLocalSeq(String localSeq) {
		this.localSeq = localSeq;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	
	@Override
	public String toString() {
		return String.format("localSeq : %s, local : %s", localSeq, local);
	}
	
}

package com.moving.DTO;

/**
 * 장르 DTO
 * @author 유기태
 * 
 */
 
public class GenreDTO {

	private String seq;
	private String genre;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
}

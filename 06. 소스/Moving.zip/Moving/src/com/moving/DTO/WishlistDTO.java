package com.moving.DTO;

/**
 * 위시리스트 DTO
 * @author 유기태
 * 
 */
 
public class WishlistDTO {

	private String memberSeq;
	private String movieSeq;
	
	public String getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(String memberSeq) {
		this.memberSeq = memberSeq;
	}
	public String getMovieSeq() {
		return movieSeq;
	}
	public void setMovieSeq(String movieSeq) {
		this.movieSeq = movieSeq;
	}
	
	@Override
	public String toString() {
		return String.format("memberSeq : %s, movieSeq : %s", memberSeq, movieSeq);
	}
	
}

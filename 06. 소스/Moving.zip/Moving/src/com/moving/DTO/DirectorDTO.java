package com.moving.DTO;

/**
 * 감독 DTO
 * @author 유기태
 * 
 */
 
public class DirectorDTO {

	//번호 이름 국적 생년월일 프로필
	private String seq;
	private String name;
	private String countrySeq;
	private String 	birthday;
	private String info;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountrySeq() {
		return countrySeq;
	}
	public void setCountrySeq(String countrySeq) {
		this.countrySeq = countrySeq;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	
}

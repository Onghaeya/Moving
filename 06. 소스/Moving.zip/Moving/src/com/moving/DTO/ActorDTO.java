package com.moving.DTO;

/**
 * 영화 배우 DTO
 * @author 유기태
 * 
 */

public class ActorDTO {

	private String seq;			//배우 번호
	private String name;		//배우명
	private String countrySeq;	//국적
	private String birth;		//생년월일
	private String profile;		//프로필
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCountrySeq() {
		return countrySeq;
	}
	public void setCountrySeq(String countrySeq) {
		this.countrySeq = countrySeq;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	
	
	
}

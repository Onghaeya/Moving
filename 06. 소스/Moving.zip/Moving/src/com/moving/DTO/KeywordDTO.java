package com.moving.DTO;

/**
 * 영화 검색 키워드 DTO
 * @author 유기태
 * 
 */
 
public class KeywordDTO {

		private String seq;
		private String keyword;
		
		public String getSeq() {
			return seq;
		}
		public void setSeq(String seq) {
			this.seq = seq;
		}
		public String getKeyword() {
			return keyword;
		}
		public void setKeyword(String keyword) {
			this.keyword = keyword;
		}
		
}

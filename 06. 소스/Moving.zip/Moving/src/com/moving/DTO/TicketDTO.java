package com.moving.DTO;

/**
 * 영화표 DTO
 * @author 유기태
 * 
 */
 
public class TicketDTO {

	private String memberSeq;
	private String onscreenSeq;
	private String seat;
	
	public String getMemberSeq() {
		return memberSeq;
	}
	public void setMemberSeq(String memberSeq) {
		this.memberSeq = memberSeq;
	}
	public String getOnscreenSeq() {
		return onscreenSeq;
	}
	public void setOnscreenSeq(String onscreenSeq) {
		this.onscreenSeq = onscreenSeq;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	
	@Override
	public String toString() {
		return String.format("memberSeq : %s, onscreenSeq : %s, seat : %s", memberSeq, onscreenSeq, seat);
	}
	
}

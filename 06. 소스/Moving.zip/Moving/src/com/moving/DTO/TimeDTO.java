package com.moving.DTO;

/**
 * 영화시간 DTO
 * @author 유기태
 * 
 */
 
public class TimeDTO {

	private String timeSeq;
	private String time;
	
	public String getTimeSeq() {
		return timeSeq;
	}
	public void setTimeSeq(String timeSeq) {
		this.timeSeq = timeSeq;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	@Override
	public String toString() {
		return String.format("timeSeq : %s, time : %s", timeSeq, time);
	}
	
}

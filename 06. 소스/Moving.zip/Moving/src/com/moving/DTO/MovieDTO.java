package com.moving.DTO;

/**
 * 영화 DTO
 * @author 유기태
 * 
 */
 
public class MovieDTO {
	
	
	private String seq;//번호
	private String title;//제목
	private String startDay;//개봉일
	private String genreSeq;//장르
	private String countrySeq;//국적
	private int audience;//관객수
	private String gradeSeq;//등급
	private String state;//개봉상태
	private int totalScore;//별점 총점
	private int reviewerNum;//별점 참가자수
	private String trailer;//예고편
	private String synopsis;//줄거리
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStartDay() {
		return startDay;
	}
	public void setStartDay(String startDay) {
		this.startDay = startDay;
	}
	public String getGenreSeq() {
		return genreSeq;
	}
	public void setGenreSeq(String genreSeq) {
		this.genreSeq = genreSeq;
	}
	public String getCountrySeq() {
		return countrySeq;
	}
	public void setCountrySeq(String countrySeq) {
		this.countrySeq = countrySeq;
	}
	public int getAudience() {
		return audience;
	}
	public void setAudience(int audience) {
		this.audience = audience;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public String getGradeSeq() {
		return gradeSeq;
	}
	public void setGradeSeq(String gradeSeq) {
		this.gradeSeq = gradeSeq;
	}
	public int getReviewerNum() {
		return reviewerNum;
	}
	public void setReviewerNum(int reviewerNum) {
		this.reviewerNum = reviewerNum;
	}
	public String getTrailer() {
		return trailer;
	}
	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	
	
	
}

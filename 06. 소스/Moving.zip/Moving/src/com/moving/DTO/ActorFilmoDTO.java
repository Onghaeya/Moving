package com.moving.DTO;

/**
 * 영화 배우 필모그래피 DTO
 * @author 유기태
 * 
 */

public class ActorFilmoDTO {

	private String actorSeq;	//배우번호
	private String movieSeq;	//영화번호
	private String movieRole;	//배우 해당영화 참여형태
	
	public String getActorSeq() {
		return actorSeq;
	}
	public void setActorSeq(String actorSeq) {
		this.actorSeq = actorSeq;
	}
	public String getMovieSeq() {
		return movieSeq;
	}
	public void setMovieSeq(String movieSeq) {
		this.movieSeq = movieSeq;
	}
	public String getMovieRole() {
		return movieRole;
	}
	public void setMovieRole(String movieRole) {
		this.movieRole = movieRole;
	}
	
}

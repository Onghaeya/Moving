package com.moving.DTO;

/**
 * 영화표 가격 DTO
 * @author 유기태
 * 
 */
 
public class PriceDTO {

	private String priceSeq;
	private String priceType;
	private int price;
	
	public String getPriceSeq() {
		return priceSeq;
	}
	public void setPriceSeq(String priceSeq) {
		this.priceSeq = priceSeq;
	}
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return String.format("priceSeq : %s, priceType : %s, price : %,d", priceSeq, priceType, price);
	}
	
}

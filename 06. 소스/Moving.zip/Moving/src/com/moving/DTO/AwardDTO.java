package com.moving.DTO;

/**
 * 영화제 DTO
 * @author 유기태
 * 
 */

public class AwardDTO {
	
	private String seq;
	private String award;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getAward() {
		return award;
	}
	public void setAward(String award) {
		this.award = award;
	}
	
}

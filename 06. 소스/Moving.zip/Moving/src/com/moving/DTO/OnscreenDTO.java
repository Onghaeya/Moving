package com.moving.DTO;

/**
 * 영화 상영 DTO
 * @author 유기태
 * 
 */
 
public class OnscreenDTO {

	private String onscreenSeq;
	private String companySeq;
	private String localSeq;
	private String movieSeq;
	private String day;
	private String timeSeq;
	private String event;
	
	public String getOnscreenSeq() {
		return onscreenSeq;
	}
	public void setOnscreenSeq(String onscreenSeq) {
		this.onscreenSeq = onscreenSeq;
	}
	public String getCompanySeq() {
		return companySeq;
	}
	public void setCompanySeq(String companySeq) {
		this.companySeq = companySeq;
	}
	public String getLocalSeq() {
		return localSeq;
	}
	public void setLocalSeq(String localSeq) {
		this.localSeq = localSeq;
	}
	public String getMovieSeq() {
		return movieSeq;
	}
	public void setMovieSeq(String movieSeq) {
		this.movieSeq = movieSeq;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getTimeSeq() {
		return timeSeq;
	}
	public void setTimeSeq(String timeSeq) {
		this.timeSeq = timeSeq;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	
	@Override
	public String toString() {
		return String.format("onscreenSeq : %s, companySeq : %s, localSeq : %s, movieSeq : %s, day : %s, timeSeq : %s, event : %s",
				onscreenSeq, companySeq, localSeq, movieSeq, day, timeSeq, event);
	}
	
}

package com.moving.DTO;

/**
 * 국가 DTO
 * @author 유기태
 * 
 */
 
public class CountryDTO {
	//번호 국적
	private String seq;
	private String country;
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}	
		
	public String toString() {
		return String.format("번호 : %s\n나라 : %s", seq, country);
	}
}

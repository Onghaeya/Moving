package com.moving.DTO;

/**
 * 영화제 상 받은 이력 DTO
 * @author 유기태
 * 
 */
 
public class AwardRecordDTO {

	//감독번호 수상영화제 상종류
	private String directorSeq;
	private String awardSeq;
	private String prizeTypeSeq;
	
	public String getDirectorSeq() {
		return directorSeq;
	}
	public void setDirectorSeq(String directorSeq) {
		this.directorSeq = directorSeq;
	}
	public String getAwardSeq() {
		return awardSeq;
	}
	public void setAwardSeq(String awardSeq) {
		this.awardSeq = awardSeq;
	}
	public String getPrizeTypeSeq() {
		return prizeTypeSeq;
	}
	public void setPrizeTypeSeq(String prizeTypeSeq) {
		this.prizeTypeSeq = prizeTypeSeq;
	}
	
}
